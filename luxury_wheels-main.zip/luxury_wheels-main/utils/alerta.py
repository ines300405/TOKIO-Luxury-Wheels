import sqlite3
from datetime import datetime, timedelta
from tkinter import Tk, messagebox
import logging

from db.conexao import conectar_base_dados  # assumes conectar_base_dados() returns an SQLite connection

logger = logging.getLogger(__name__)


def alertar_revisoes_proximas(dias_aviso: int = 5) -> None:

    """
    Checks vehicles whose next service date occurs within the next `days_notice` days
    and shows an alert via messagebox if such vehicles exist.

    Args:
        days_notice (int): Number of days to look ahead for upcoming services. Default is 5 days.

    Flow:
        1. Connects to the SQLite database.
        2. Calculates the cutoff date based on days_notice.
        3. Selects vehicles that are 'available' and have a service scheduled within the period.
        4. If any vehicles exist, builds a message listing them.
        5. Displays a Tkinter messagebox alert.
        6. Closes the database connection.
    """
    conexao = conectar_base_dados()
    if conexao is None:
        logger.error("Failed to connect to the database.")
        return

    try:
        conexao.row_factory = sqlite3.Row   # allows access by column name
        data_hoje = datetime.today().date()
        data_limite = data_hoje + timedelta(days=dias_aviso)

        consulta_sql  = """
             SELECT id, marca, modelo, data_proxima_revisao
            FROM Veiculos
            WHERE data_proxima_revisao BETWEEN ? AND ?
              AND estado = 'disponível'
            ORDER BY data_proxima_revisao
        """

        cursor = conexao.cursor()
        cursor.execute(consulta_sql, (data_hoje.isoformat(), data_limite.isoformat()))
        veiculos_com_revisao_proxima = cursor.fetchall()

        if veiculos_com_revisao_proxima:
            linhas_veiculos = [
                f"- {veiculo['marca']} {veiculo['modelo']} (Revisão: {veiculo['data_proxima_revisao']})"
                for veiculo in veiculos_com_revisao_proxima
            ]
            mensagem_alerta  = "Vehicles with upcoming service:\n" + "\n".join(linhas_veiculos)

            # Create a hidden Tk window to use messagebox without mainloop
            janela_raiz  = Tk()
            janela_raiz.withdraw()
            messagebox.showwarning("Service Alert", mensagem_alerta, parent=janela_raiz )
            janela_raiz.destroy()

    except Exception:
        logger.exception("Error checking upcoming services")
    finally:
        conexao.close()
