import os
from PIL import Image

path = r"C:\TOKIO\ProjetoFinal\photo_cars\Mitsubishi_Pajero_sport.jpg"
img = Image.open(path)
img.show()
