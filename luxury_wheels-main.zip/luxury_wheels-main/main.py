import tkinter as tk
from tkinter import messagebox, Toplevel, ttk

from ui.cliente_ui import AplicacaoClientes
from ui.veiculo_ui import AplicacaoVeiculo
from ui.reserva_ui import AplicacaoReserva
from ui.forma_pagamento_ui import AplicacaoFormasPagamento
from ui.pagamento_ui import AplicacaoPagamentos
from ui.dashboard_ui import AplicacaoDashboard
from utils.alerta import alertar_revisoes_proximas
from ui.login_ui import abrir_login
from controllers.utilizadores.utilizador_validacoes import validar_user


class MainApp(ttk.Frame):
    """
    Main interface of the Luxury Wheels application.

    Manages the main menu, allowing navigation between modules
    (clients, vehicles, reservations, payments, payment methods, dashboard)
    via buttons.
    """

    NAV_BUTTONS = [
        ("Client Management", AplicacaoClientes, "Clients"),
        ("Vehicle Management", AplicacaoVeiculo, "Vehicles"),
        ("Reservation Management", AplicacaoReserva, "Reservations"),
        ("Payment Methods", AplicacaoFormasPagamento, "PaymentMethods"),
        ("Payment Management", AplicacaoPagamentos, "Payments"),
        ("Dashboard", AplicacaoDashboard, "Dashboard"),
    ]

    def __init__(self, master: tk.Widget, user: dict):
        """
        Initialize the main interface.

        Args:
            master (tk.Widget): Parent window (typically Tk root).
            user (dict): Validated user data with id, nome, perfil.
        """
        super().__init__(master, padding=20)
        self.master = master
        self.user = user
        self.active_windows = {}

        self._setup_styles()
        self._build_interface()

        # Welcome message and maintenance alert
        self.after(100, lambda: messagebox.showinfo("Welcome", f"Welcome {self.user['nome']} ({self.user['perfil']})"))
        self.after(200, alertar_revisoes_proximas)
        self.pack(fill="both", expand=True)

    def _setup_styles(self):
        """Define ttk styles for labels and buttons."""
        style = ttk.Style()
        style.theme_use('clam')

        style.configure(
            "Header.TLabel",
            font=("Segoe UI", 18, "bold"),
            foreground="#333333",
            background="#f0f0f0"
        )

        style.configure(
            "Nav.TButton",
            font=("Segoe UI", 11, "bold"),
            padding=8,
            foreground="white",
        )
        style.map(
            "Nav.TButton",
            background=[("!active", "#1e90ff"), ("active", "#104e8b")],
            foreground=[("!active", "white"), ("active", "white")],
        )

        style.configure(
            "Exit.TButton",
            font=("Segoe UI", 11, "bold"),
            padding=8,
            foreground="white",
        )
        style.map(
            "Exit.TButton",
            background=[("!active", "#d32f2f"), ("active", "#b71c1c")],
            foreground=[("!active", "white"), ("active", "white")],
        )

    def _build_interface(self):
        """Builds the visual interface for the main menu."""
        header_label = ttk.Label(self, text="Main Menu", style="Header.TLabel")
        header_label.pack(pady=(0, 20))

        nav_frame = ttk.Frame(self, padding=(0, 10))
        nav_frame.pack(fill="x")

        for text, AppClass, key in self.NAV_BUTTONS:
            btn = ttk.Button(
                nav_frame,
                text=text,
                style="Nav.TButton",
                command=lambda c=AppClass, k=key: self._open_window(c, k)
            )
            btn.pack(fill="x", pady=5)

        exit_btn = ttk.Button(
            self,
            text="Exit Application",
            style="Exit.TButton",
            command=self._exit_app
        )
        exit_btn.pack(pady=(30, 0))

    def _open_window(self, AppClass, window_key: str):
        """Opens a new Toplevel window for the selected module."""
        existing_window = self.active_windows.get(window_key)
        if existing_window and existing_window.winfo_exists():
            existing_window.lift()
            return

        new_window = Toplevel(self.master)
        new_window.title(window_key)
        new_window.configure(bg="#f0f0f0")

        self.active_windows[window_key] = new_window
        AppClass(new_window)

    def _exit_app(self):
        """Shows confirmation and closes the application."""
        if messagebox.askokcancel("Exit", "Do you really want to exit the application?"):
            self.master.destroy()


def iniciar_main_app(user):
    """
    Start the main application after successful login.
    The user is validated before loading the main interface.
    """
    user_data = validar_user(user)
    if not user_data:
        return  # Abort if invalid

    root = tk.Tk()
    root.title(f"Luxury Wheels – Fleet Management ({user_data['nome']} - {user_data['perfil']})")
    root.geometry("1000x700")
    root.configure(bg="#f0f0f0")
    root.resizable(True, True)

    canvas = tk.Canvas(root, bg="#f0f0f0", highlightthickness=0)
    vertical_scrollbar = ttk.Scrollbar(root, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=vertical_scrollbar.set)

    vertical_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    container_frame = ttk.Frame(canvas, padding=20)
    canvas_frame_id = canvas.create_window((0, 0), window=container_frame, anchor="nw")

    def on_frame_configure(event):
        canvas.configure(scrollregion=canvas.bbox("all"))

    def on_canvas_configure(event):
        canvas.itemconfig(canvas_frame_id, width=event.width)

    container_frame.bind("<Configure>", on_frame_configure)
    canvas.bind("<Configure>", on_canvas_configure)

    app = MainApp(container_frame, user_data)
    app.pack(fill=tk.BOTH, expand=True)

    root.mainloop()


if __name__ == "__main__":
    # First request login; if successful, call iniciar_main_app(user)
    abrir_login(iniciar_main_app)
