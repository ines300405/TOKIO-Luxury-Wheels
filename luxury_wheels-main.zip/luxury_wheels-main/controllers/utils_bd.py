import logging
from typing import Any, Optional
from contextlib import contextmanager
from db.conexao import conectar_base_dados
import sqlite3

logger = logging.getLogger(__name__)
if not logger.hasHandlers():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    )

@contextmanager
def obter_cursor(commit: bool = False):
    """
    Context manager to obtain a SQLite database cursor.

    This cursor returns results as dictionaries (sqlite3.Row).
    Automatically closes the cursor and connection at the end of the block.
    Commits if commit=True, or rolls back in case of error.

    Parameters:
        commit (bool): If True, commits at the end of the block (default=False).

    Yields:
        sqlite3.Cursor: Database cursor ready to execute queries.

    Exceptions:
        ConnectionError: If the connection to the database fails.
        Re-raises any exception that occurs during block execution.
    """
    conexao = conectar_base_dados()
    if conexao is None:
        logger.error("Failed to connect to the database.")
        raise ConnectionError("Database connection failed.")

    # Set row_factory to return dictionaries
    conexao.row_factory = sqlite3.Row

    cursor = conexao.cursor()
    try:
        yield cursor
        if commit:
            conexao.commit()  # only commit if commit=True
    except Exception:
        conexao.rollback()
        raise
    finally:
        cursor.close()
        conexao.close()


def executar_query_valor_unico(query: str, parametros: Optional[tuple] = None) -> Any:
    """
    Executes a query that returns a single value (e.g., COUNT, SUM, MAX).

    Parameters:
        query (str): The SQL query to execute.
        parametros (tuple, optional): Parameters for the query (default=None).

    Returns:
        Any: The scalar value returned by the query, or None if there are no results or an error occurs.

    Log:
        Logs an exception if an error occurs while executing the query.
    """
    try:
        with obter_cursor() as cursor:
            cursor.execute(query, parametros or ())
            resultado = cursor.fetchone()
            return resultado[0] if resultado else None
    except Exception:
        logger.exception("Error executing scalar query: %s", query)
        return None
