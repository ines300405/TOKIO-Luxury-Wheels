"""
Database access module for payment methods.

Responsible for CRUD operations (Create, Read, Update, Delete) on the
`PaymentMethods` table. Also ensures the table is created if it does not exist.
"""

import logging
from typing import List, Optional, Dict
from controllers.utils_bd import obter_cursor

logger = logging.getLogger(__name__)


def criar_tabela_formas_pagamento() -> None:
    """
    Creates the `PaymentMethods` table if it does not exist.

    Structure:
        - id (INTEGER, PK, AUTOINCREMENT)
        - method (TEXT, NOT NULL)
    """
    query = """
    CREATE TABLE IF NOT EXISTS FormasPagamento (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        metodo TEXT NOT NULL
    )
    """
    try:
        with obter_cursor(commit=True) as cursor:
            cursor.execute(query)
    except Exception:
        logger.exception("Error creating PaymentMethods table")


def adicionar_forma_pagamento_bd(metodo: str) -> bool:
    """
    Inserts a new payment method.

    Args:
        metodo (str): Name of the payment method.

    Returns:
        bool: True if the insertion was successful, False otherwise.
    """
    try:
        with obter_cursor(commit=True) as cursor:
            cursor.execute(
                "INSERT INTO FormasPagamento (metodo) VALUES (?)",
                (metodo.strip(),)
            )
        return True
    except Exception:
        logger.exception("Error adding payment method")
        return False


def listar_formas_pagamento_bd() -> List[Dict]:
    """
    Returns all existing payment methods.

    Returns:
        List[Dict]: List of dictionaries with the keys:
            - id (int): Payment method identifier
            - metodo (str): Name of the payment method
    """
    try:
        with obter_cursor() as cursor:
            cursor.execute("SELECT id, metodo FROM FormasPagamento")
            colunas = [desc[0] for desc in cursor.description]
            return [dict(zip(colunas, linha)) for linha in cursor.fetchall()]
    except Exception:
        logger.exception("Error listing payment methods")
        return []


def atualizar_forma_pagamento_bd(id_pagamento: int, novo_nome: str) -> bool:
    """
    Updates the name of a payment method.

    Args:
        id_pagamento (int): ID of the payment method to update.
        novo_nome (str): New method name.

    Returns:
        bool: True if the update was successful, False otherwise.
    """
    try:
        with obter_cursor(commit=True) as cursor:
            cursor.execute(
                "UPDATE FormasPagamento SET metodo = ? WHERE id = ?",
                (novo_nome.strip(), id_pagamento)
            )
            return cursor.rowcount > 0
    except Exception:
        logger.exception("Error updating payment method")
        return False


def remover_forma_pagamento_bd(id_pagamento: int) -> bool:
    """
    Removes a payment method by ID.

    Args:
        id_pagamento (int): ID of the payment method to remove.

    Returns:
        bool: True if the removal was successful, False otherwise.
    """
    try:
        with obter_cursor(commit=True) as cursor:
            cursor.execute(
                "DELETE FROM FormasPagamento WHERE id = ?",
                (id_pagamento,)
            )
            return cursor.rowcount > 0
    except Exception:
        logger.exception("Error removing payment method")
        return False


def buscar_forma_pagamento_por_id(id_pagamento: int) -> Optional[Dict]:
    """
    Searches for a payment method by ID.

    Args:
        id_pagamento (int): Payment method identifier.

    Returns:
        Optional[Dict]: Dictionary with `id` and `metodo` fields,
        or None if not found.
    """
    try:
        with obter_cursor() as cursor:
            cursor.execute("SELECT id, metodo FROM FormasPagamento WHERE id = ?", (id_pagamento,))
            resultado = cursor.fetchone()
            if resultado:
                colunas = [desc[0] for desc in cursor.description]
                return dict(zip(colunas, resultado))
            return None
    except Exception:
        logger.exception("Error searching payment method by ID")
        return None
