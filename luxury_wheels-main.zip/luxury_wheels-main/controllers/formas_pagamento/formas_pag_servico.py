"""
Payment Methods Control Module.

Responsible for:
- Initializing the table in the database
- CRUD operations with validation
- Exporting data to CSV
"""

import logging
import csv
from typing import List, Dict, Tuple
from controllers.formas_pagamento.formas_pag_validacao import nome_forma_pagamento_valido
from controllers.formas_pagamento.formas_pag_repositorio import (
    criar_tabela_formas_pagamento,
    adicionar_forma_pagamento_bd,
    listar_formas_pagamento_bd,
    atualizar_forma_pagamento_bd,
    remover_forma_pagamento_bd,
    buscar_forma_pagamento_por_id
)

logger = logging.getLogger(__name__)


def inicializar_formas_pagamento() -> None:
    """
    Creates the `PaymentMethods` table if it does not exist.

    Logs:
        - INFO: if the table is created or already exists
        - EXCEPTION: in case of failure
    """
    try:
        criar_tabela_formas_pagamento()
        logger.info("Table 'PaymentMethods' created or already exists.")
    except Exception:
        logger.exception("Error creating table 'PaymentMethods'.")


def adicionar_forma_pagamento(metodo: str) -> bool:
    """
    Adds a new payment method after validation.

    Args:
        metodo (str): Name of the payment method.

    Returns:
        bool: True if added successfully, False otherwise.
    """
    if not nome_forma_pagamento_valido(metodo):
        logger.warning("Invalid method: '%s'", metodo)
        return False
    return adicionar_forma_pagamento_bd(metodo)


def editar_forma_pagamento(id_pagamento: int, novo_nome: str) -> bool:
    """
    Updates the name of a payment method.

    Args:
        id_pagamento (int): ID of the payment method to edit.
        novo_nome (str): New method name.

    Returns:
        bool: True if updated successfully, False otherwise.
    """
    if not nome_forma_pagamento_valido(novo_nome):
        logger.warning("Invalid new name.")
        return False
    return atualizar_forma_pagamento_bd(id_pagamento, novo_nome)


def excluir_forma_pagamento(id_pagamento: int) -> bool:
    """
    Removes a payment method from the database.

    Args:
        id_pagamento (int): ID of the payment method.

    Returns:
        bool: True if removed successfully, False otherwise.
    """
    return remover_forma_pagamento_bd(id_pagamento)


def obter_formas_pagamento() -> List[Tuple[int, str]]:
    """
    Lists all existing payment methods.

    Returns:
        List[Tuple[int, str]]: List of tuples in the format (id, method).
    """
    resultados = listar_formas_pagamento_bd()
    return [(fp["id"], fp["metodo"]) for fp in resultados]


def buscar_forma_pagamento(id_pagamento: int) -> Dict:
    """
    Searches for a payment method by ID.

    Args:
        id_pagamento (int): ID of the payment method.

    Returns:
        Dict: Dictionary with the payment method fields,
        or {} if not found.
    """
    return buscar_forma_pagamento_por_id(id_pagamento)


def exportar_formas_pagamento_para_csv(nome_arquivo: str = "formas_pagamento_export.csv") -> bool:
    """
    Exports payment methods to a CSV file.

    Args:
        nome_arquivo (str, optional): Destination file name.
            Default = "formas_pagamento_export.csv".

    Returns:
        bool: True if exported successfully, False otherwise.
    """
    formas = obter_formas_pagamento()
    if not formas:
        logger.warning("No payment methods to export.")
        return False
    try:
        with open(nome_arquivo, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["ID", "Name"])
            writer.writerows(formas)
        return True
    except Exception:
        logger.exception("Error exporting payment methods")
        return False
