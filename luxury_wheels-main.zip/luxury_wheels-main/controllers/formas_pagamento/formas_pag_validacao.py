import re

def nome_forma_pagamento_valido(nome: str) -> bool:
    """
    Checks if the payment method name is valid.

    Rules:
        - Non-empty string
        - Minimum 3 characters
        - Maximum 50 characters
        - Only letters, numbers, and spaces

    Args:
        nome (str): Name to validate.

    Returns:
        bool: True if valid, False otherwise.
    """
    if not isinstance(nome, str):
        return False
    nome = nome.strip()
    if not (3 <= len(nome) <= 50):
        return False
    return bool(re.match(r"^[A-Za-zÀ-ÿ0-9 ]+$", nome))
