"""
Service layer for the business logic of reservations.

Validates data before interacting with the repository and provides functions
to add, update, remove, list, and export reservations.
"""

import logging
import csv
from controllers.reservas.reservas_validacoes import validar_periodo, validar_valor, validar_status, validar_ids
from controllers.reservas.reservas_repositorio import (
    inserir_reserva_bd,
    atualizar_reserva_bd,
    remover_reserva_bd,
    listar_reservas_bd
)

logger = logging.getLogger(__name__)

def adicionar_reserva_servico(data_inicio: str, data_fim: str, cliente_id: int,
                              veiculo_id: int, status: str, valor_total: float) -> bool:
    """
    Adds a new reservation after validating the data.

    Args:
        data_inicio (str): Reservation start date (format YYYY-MM-DD)
        data_fim (str): Reservation end date (format YYYY-MM-DD)
        cliente_id (int): Client ID
        veiculo_id (int): Vehicle ID
        status (str): Reservation status (e.g., "Confirmed", "Pending")
        valor_total (float): Total reservation value

    Returns:
        bool: True if the reservation was added successfully, False otherwise
    """
    if not (validar_ids(cliente_id, veiculo_id) and validar_periodo(data_inicio, data_fim)
            and validar_status(status) and validar_valor(valor_total)):
        return False

    dados = {
        "id_cliente": cliente_id,
        "id_veiculo": veiculo_id,
        "data_inicio": data_inicio,
        "data_fim": data_fim,
        "estado": status.strip(),
        "valor_total": valor_total
    }

    novo_id = inserir_reserva_bd(dados)
    return novo_id is not None

def obter_reservas_servico() -> list[dict]:
    """
    Returns all existing reservations.

    Returns:
        List[Dict]: List of dictionaries representing each reservation
    """
    return listar_reservas_bd()

def atualizar_reserva_servico(reserva_id: int, data_inicio: str, data_fim: str,
                              cliente_id: int, veiculo_id: int, status: str, valor_total: float) -> bool:
    """
    Updates an existing reservation after validating the data.

    Args:
        reserva_id (int): Reservation ID
        data_inicio (str): Reservation start date
        data_fim (str): Reservation end date
        cliente_id (int): Client ID
        veiculo_id (int): Vehicle ID
        status (str): Reservation status
        valor_total (float): Total value

    Returns:
        bool: True if the update was successful, False otherwise
    """
    if not (validar_ids(reserva_id, cliente_id, veiculo_id) and validar_periodo(data_inicio, data_fim)
            and validar_status(status) and validar_valor(valor_total)):
        return False

    dados = {
        "id": reserva_id,
        "id_cliente": cliente_id,
        "id_veiculo": veiculo_id,
        "data_inicio": data_inicio,
        "data_fim": data_fim,
        "estado": status.strip(),
        "valor_total": valor_total
    }

    return atualizar_reserva_bd(dados)

def excluir_reserva_servico(reserva_id: int) -> bool:
    """
    Removes a reservation by ID after validation.

    Args:
        reserva_id (int): ID of the reservation to remove

    Returns:
        bool: True if the deletion was successful, False otherwise
    """
    if not validar_ids(reserva_id):
        return False
    return remover_reserva_bd(reserva_id)

def exportar_reservas_para_csv(nome_arquivo: str = "reservas_export.csv") -> bool:
    """
    Exports all reservations to a CSV file.

    Args:
        nome_arquivo (str): Destination file name (default: "reservas_export.csv")

    Returns:
        bool: True if the export was completed successfully, False otherwise
    """
    reservas = listar_reservas_bd()
    if not reservas:
        logger.warning("No reservations to export")
        return False
    try:
        with open(nome_arquivo, mode="w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["ID", "Client", "Vehicle", "Start Date", "End Date", "Status", "Total Value"])
            for r in reservas:
                writer.writerow([r["id"], r["id_cliente"], r["id_veiculo"],
                                 r["data_inicio"], r["data_fim"], r["estado"], r["valor_total"]])
        logger.info("Export completed to %s", nome_arquivo)
        return True
    except Exception:
        logger.exception("Error exporting reservations.")
        return False
