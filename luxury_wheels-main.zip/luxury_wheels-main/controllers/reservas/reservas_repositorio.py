"""
Database access module for reservations.

Provides CRUD functions for the 'Reservas' table, including insertion,
listing, updating, deletion, and lookup by ID.
"""

import logging
from typing import List, Dict, Optional
from controllers.utils_bd import obter_cursor
from controllers.veiculos.veiculos_repositorio import buscar_veiculo_por_id


logger = logging.getLogger(__name__)

def inserir_reserva_bd(dados: Dict) -> Optional[int]:
    """
    Inserts a new reservation into the database.

    Args:
        dados (Dict): Dictionary with the fields:
            - data_inicio (str)
            - data_fim (str)
            - id_cliente (int)
            - id_veiculo (int)
            - estado (str)
            - valor_total (float)

    Returns:
        Optional[int]: ID of the inserted reservation or None if an error occurs.
    """
    sql = """
        INSERT INTO Reservas (data_inicio, data_fim, id_cliente, id_veiculo, estado, valor_total)
        VALUES (?, ?, ?, ?, ?, ?)
    """
    try:
        with obter_cursor(commit=True) as cur:
            cur.execute(sql, (
                dados["data_inicio"],
                dados["data_fim"],
                int(dados["id_cliente"]),
                int(dados["id_veiculo"]),
                dados["estado"],
                float(dados["valor_total"])
            ))
            novo_id = cur.lastrowid
        logger.info("Reservation inserted: client=%d, vehicle=%d, id=%d",
                    dados["id_cliente"], dados["id_veiculo"], novo_id)
        return novo_id
    except Exception:
        logger.exception("Error inserting reservation.")
        return None

def listar_reservas_bd() -> List[Dict]:
    """
    Returns all existing reservations from the database.

    Returns:
        List[Dict]: List of dictionaries representing each reservation.
    """
    sql = """
        SELECT id, id_cliente, id_veiculo, data_inicio, data_fim, estado, valor_total
        FROM Reservas ORDER BY data_inicio DESC
    """
    try:
        with obter_cursor() as cur:
            cur.execute(sql)
            colunas = [desc[0] for desc in cur.description]
            return [dict(zip(colunas, linha)) for linha in cur.fetchall()]
    except Exception:
        logger.exception("Error listing reservations.")
        return []

def atualizar_reserva_bd(dados: Dict) -> bool:
    """
    Updates an existing reservation in the database.

    Args:
        dados (Dict): Dictionary with the fields:
            - id (int)
            - data_inicio (str)
            - data_fim (str)
            - id_cliente (int)
            - id_veiculo (int)
            - estado (str)
            - valor_total (float)

    Returns:
        bool: True if the update was successful, False otherwise.
    """
    sql = """
        UPDATE Reservas
        SET data_inicio = ?, data_fim = ?, id_cliente = ?, id_veiculo = ?, estado = ?, valor_total = ?
        WHERE id = ?
    """
    try:
        with obter_cursor(commit=True) as cur:
            cur.execute(sql, (
                dados["data_inicio"],
                dados["data_fim"],
                int(dados["id_cliente"]),
                int(dados["id_veiculo"]),
                dados["estado"],
                float(dados["valor_total"]),
                int(dados["id"])
            ))
            return cur.rowcount > 0
    except Exception:
        logger.exception("Error updating reservation.")
        return False

def remover_reserva_bd(reserva_id: int) -> bool:
    """
    Removes a reservation from the database by ID.

    Args:
        reserva_id (int): ID of the reservation to remove.

    Returns:
        bool: True if successfully removed, False otherwise.
    """
    sql = "DELETE FROM Reservas WHERE id = ?"
    try:
        with obter_cursor(commit=True) as cur:
            cur.execute(sql, (reserva_id,))
            return cur.rowcount > 0
    except Exception:
        logger.exception("Error removing reservation.")
        return False

def buscar_reserva_por_id(reserva_id: int) -> Optional[Dict]:
    """
    Retrieves a reservation by its ID.

    Args:
        reserva_id (int): Reservation ID.

    Returns:
        Optional[Dict]: Dictionary with the reservation data or None if not found.
    """
    sql = """
        SELECT id, id_cliente AS cliente_id, id_veiculo AS veiculo_id, data_inicio, data_fim, estado AS status, valor_total
        FROM Reservas WHERE id = ?
    """
    try:
        with obter_cursor() as cur:
            cur.execute(sql, (reserva_id,))
            resultado = cur.fetchone()
            if resultado:
                colunas = [desc[0] for desc in cur.description]
                return dict(zip(colunas, resultado))
            return None
    except Exception:
        logger.exception("Error fetching reservation by ID.")
        return None

def obter_diaria_veiculo(veiculo_id: int) -> float:
    veiculo = buscar_veiculo_por_id(veiculo_id)
    if veiculo and veiculo.get("diaria"):
        try:
            return float(veiculo["diaria"])
        except ValueError:
            return 0.0
    return 0.0






