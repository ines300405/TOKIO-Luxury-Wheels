"""
Reservation data validation functions.

Validates dates, values, IDs, status, and reservation periods.
Includes error logging to aid debugging.
"""

from datetime import datetime
from typing import Any
from math import isfinite
import logging

logger = logging.getLogger(__name__)

def validar_data(data_str: str, formato: str = "%Y-%m-%d") -> bool:
    """
    Checks if the provided date is in the expected format.

    Args:
        data_str (str): Date to validate
        formato (str): Date format (default: "%Y-%m-%d")

    Returns:
        bool: True if the date is valid, False otherwise
    """
    try:
        datetime.strptime(data_str, formato)
        return True
    except Exception:
        logger.error("Invalid date: %s", data_str)
        return False

def validar_valor(valor: Any) -> bool:
    """
    Validates if the value is numeric, finite, and non-negative.

    Args:
        valor (Any): Value to validate

    Returns:
        bool: True if valid, False otherwise
    """
    try:
        v = float(valor)
        if v >= 0 and isfinite(v):
            return True
    except Exception:
        pass
    logger.error("Invalid value: %s", valor)
    return False

def validar_ids(*ids: Any) -> bool:
    """
    Validates that all provided IDs are positive integers.

    Args:
        *ids (Any): One or more IDs to validate

    Returns:
        bool: True if all IDs are valid, False otherwise
    """
    valido = all(isinstance(i, int) and i > 0 for i in ids)
    if not valido:
        logger.error("Invalid IDs: %s", ids)
    return valido

def validar_status(status: str) -> bool:
    """
    Validates that the status is a non-empty string.

    Args:
        status (str): Status to validate

    Returns:
        bool: True if valid, False otherwise
    """
    if isinstance(status, str) and status.strip():
        return True
    logger.error("Invalid status: '%s'", status)
    return False

def validar_periodo(data_inicio: str, data_fim: str) -> bool:
    """
    Validates that the period is coherent: valid dates and end_date >= start_date.

    Args:
        data_inicio (str): Start date
        data_fim (str): End date

    Returns:
        bool: True if the period is valid, False otherwise
    """
    if not (validar_data(data_inicio) and validar_data(data_fim)):
        return False
    if datetime.strptime(data_fim, "%Y-%m-%d") < datetime.strptime(data_inicio, "%Y-%m-%d"):
        logger.error("End date is earlier than start date.")
        return False
    return True
