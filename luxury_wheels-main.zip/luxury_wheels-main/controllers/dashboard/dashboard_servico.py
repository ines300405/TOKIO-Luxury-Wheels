"""
Dashboard Service.

Provides high-level functions to access system statistics,
based on queries from the `dashboard_repositorio` module.

The functions return counts of customers, vehicles, reservations, and revenue,
as well as aggregated reports of reservations per month.
"""

from typing import List, Dict
from controllers.dashboard.dashboard_repositorio import (
    contar_clientes,
    contar_veiculos_disponiveis,
    contar_reservas_ativas,
    somar_valor_pagamentos,
    reservas_agrupadas_por_mes
)


def obter_total_clientes() -> int:
    """
    Gets the total number of customers.

    Returns:
        int: Total number of registered customers.
    """
    return contar_clientes().get("total_clientes", 0)


def obter_total_veiculos_disponiveis() -> int:
    """
    Gets the number of available vehicles.

    Returns:
        int: Number of currently available vehicles.
    """
    return contar_veiculos_disponiveis().get("total_veiculos_disponiveis", 0)


def obter_total_reservas_ativas() -> int:
    """
    Gets the number of active reservations (Confirmed or Pending).

    Returns:
        int: Number of active reservations.
    """
    return contar_reservas_ativas().get("total_reservas_ativas", 0)


def calcular_receita_total_pagamentos() -> float:
    """
    Gets the total amount received in payments.

    Returns:
        float: Total accumulated revenue.
    """
    return somar_valor_pagamentos().get("receita_total", 0.0)


def obter_reservas_agrupadas_por_mes() -> List[Dict[str, int]]:
    """
    Gets the list of reservations grouped by month.

    Returns:
        List[Dict[str, int]]: List of dictionaries in the format:
            [{"month": "2025-01", "total": 5}, {"month": "2025-02", "total": 8}]
    """
    return reservas_agrupadas_por_mes()
