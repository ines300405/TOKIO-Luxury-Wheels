"""
System statistics and reporting module.

Provides functions to obtain metrics from the database,
such as count of customers, available vehicles, active reservations,
and total revenue calculation.

Also includes grouped queries (e.g., reservations per month) for
use in dashboards or reports.
"""

from typing import List, Dict
from controllers.utils_bd import executar_query_valor_unico, obter_cursor
import logging

logger = logging.getLogger(__name__)


def contar_clientes() -> Dict[str, int]:
    """
    Counts the total number of registered customers.

    Returns:
        Dict[str, int]: Dictionary with the key "total_customers" and its value.
    """
    try:
        total = executar_query_valor_unico("SELECT COUNT(*) FROM Clientes") or 0
        return {"total_customers": int(total)}
    except Exception:
        logger.exception("Error counting customers")
        return {"total_customers": 0}


def contar_veiculos_disponiveis() -> Dict[str, int]:
    """
    Counts the number of available vehicles.

    Returns:
        Dict[str, int]: Dictionary with the key "total_available_vehicles" and its value.
    """
    try:
        total = executar_query_valor_unico(
            "SELECT COUNT(*) FROM Veiculos WHERE estado = ?", ("disponível",)
        ) or 0
        return {"total_available_vehicles": int(total)}
    except Exception:
        logger.exception("Error counting available vehicles")
        return {"total_available_vehicles": 0}


def contar_reservas_ativas() -> Dict[str, int]:
    """
    Counts the number of active reservations (Confirmed or Pending).

    Returns:
        Dict[str, int]: Dictionary with the key "total_active_reservations" and its value.
    """
    try:
        total = executar_query_valor_unico(
            "SELECT COUNT(*) FROM Reservas WHERE estado IN (?, ?)", ("Confirmada", "Pendente")
        ) or 0
        return {"total_active_reservations": int(total)}
    except Exception:
        logger.exception("Error counting active reservations")
        return {"total_active_reservations": 0}


def somar_valor_pagamentos() -> Dict[str, float]:
    """
    Calculates the total amount received in payments.

    Returns:
        Dict[str, float]: Dictionary with the key "total_revenue" and its value.
    """
    try:
        total = executar_query_valor_unico("SELECT SUM(valor) FROM Pagamentos") or 0.0
        return {"total_revenue": float(total)}
    except Exception:
        logger.exception("Error summing payment amounts")
        return {"total_revenue": 0.0}


def reservas_agrupadas_por_mes() -> List[Dict[str, int]]:
    """
    Returns a list with the total number of reservations grouped by month.

    Returns:
        List[Dict[str, int]]: List of dictionaries in the format:
            [{"month": "2025-01", "total": 5}, {"month": "2025-02", "total": 8}]
    """
    query = """
        SELECT strftime('%Y-%m', data_inicio) AS month, COUNT(*) AS total
        FROM Reservas
        GROUP BY month
        ORDER BY month;
    """
    try:
        with obter_cursor() as cursor:
            cursor.execute(query)
            resultados = cursor.fetchall()
            return [{"month": month, "total": total} for month, total in resultados]
    except Exception:
        logger.exception("Error fetching reservations grouped by month")
        return []
