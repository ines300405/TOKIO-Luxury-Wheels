from tkinter import messagebox

def validar_user(user: tuple) -> dict | None:
    """
    Validate the user data returned by the login process.

    Args:
        user (tuple): Tuple in the format (id, nome, email, perfil)

    Returns:
        dict: Validated user with keys 'id', 'nome', 'email', 'perfil'
        None: If invalid
    """
    if not user or len(user) < 4:
        messagebox.showerror("Error", "Invalid session. Please restart the application.")
        return None

    user_id, user_nome, user_email, user_perfil = user

    # Name validation for login
    if not user_nome or not isinstance(user_nome, str) or len(user_nome.strip()) < 3:
        messagebox.showerror("Error", "Invalid user name. Name must have at least 3 characters.")
        return None

    # Email validation for login
    if not user_email or "@" not in user_email:
        messagebox.showerror("Error", "Invalid email. Email must contain '@'.")
        return None

    # Profile validation
    if user_perfil not in ("admin", "gestor"):
        messagebox.showerror("Error", f"Invalid profile: {user_perfil}")
        return None

    return {
        "id": user_id,
        "nome": user_nome.strip(),
        "email": user_email.strip(),
        "perfil": user_perfil
    }


def validar_user_dados(nome: str, email: str, perfil: str) -> tuple[bool, str]:
    """
    Validate user data before registration.

    Args:
        nome (str): User name
        email (str): User email
        perfil (str): User profile ('admin' or 'gestor')

    Returns:
        tuple: (True, "") if valid, or (False, "Error message") if invalid
    """
    # Name validation
    if not nome or len(nome.strip()) < 3:
        return False, "Invalid user name. Name must have at least 3 characters."

    # Email validation
    if not email or "@" not in email:
        return False, "Invalid email. Email must contain '@'."

    # Profile validation
    if perfil not in ("admin", "gestor"):
        return False, f"Invalid profile: {perfil}"

    return True, ""
