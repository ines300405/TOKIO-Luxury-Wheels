import sqlite3
import hashlib
from db.conexao import conectar_base_dados
from controllers.utilizadores.utilizador_validacoes import validar_user_dados
from tkinter import messagebox

def hash_password(password: str) -> str:
    """Apply SHA-256 hash to the password."""
    return hashlib.sha256(password.encode()).hexdigest()

def criar_utilizador(nome: str, email: str, senha: str, perfil: str = "gestor") -> bool:
    """
    Register a new user in the system after validating the data.

    Args:
        nome (str): User name
        email (str): User email
        senha (str): User password
        perfil (str): User profile ('admin' or 'gestor')

    Returns:
        bool: True if the user was created successfully, False otherwise.
    """

    # Validate the input data before inserting into the database
    valido, mensagem = validar_user_dados(nome, email, perfil)
    if not valido:
        messagebox.showerror("Error", mensagem)  # Show validation error to the user
        return False  # Do not insert into the database

    conn = conectar_base_dados()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT INTO utilizadores (nome, email, senha, perfil)
            VALUES (?, ?, ?, ?)
        """, (nome.strip(), email.strip(), hash_password(senha), perfil))
        conn.commit()
        messagebox.showinfo("Success", "User registered successfully!")
        return True
    except sqlite3.IntegrityError:
        messagebox.showerror("Error", "Email already exists.")
        return False
    finally:
        conn.close()

def verificar_login(email: str, senha: str):
    """
    Check if the login is valid.

    Args:
        email (str): User email
        senha (str): User password

    Returns:
        tuple | None: Returns user data (id, nome, email, perfil) if valid, None otherwise.
    """
    conn = conectar_base_dados()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT id, nome, email, perfil FROM utilizadores
        WHERE email = ? AND senha = ?
    """, (email.strip(), hash_password(senha)))
    user = cursor.fetchone()
    conn.close()
    return user  # Returns None if the user does not exist
