"""
Payment data validation functions.

This module provides functions to validate dates, monetary values, and IDs
used in payments. All functions return booleans indicating
whether the data is valid or not.
"""

from datetime import datetime
from typing import Any
from math import isfinite

def data_valida(data_str: str, formato: str = "%Y-%m-%d") -> bool:
    """
    Checks if the provided date is in the expected format.

    Args:
        data_str (str): Date to validate.
        formato (str): Date format (default "%Y-%m-%d").

    Returns:
        bool: True if the date is valid, False otherwise.

    Example:
        >>> data_valida("2025-08-25")
        True
        >>> data_valida("25/08/2025")
        False
    """
    try:
        datetime.strptime(data_str, formato)
        return True
    except (ValueError, TypeError):
        return False

def valor_valido(valor: Any) -> bool:
    """
    Validates whether the value is numeric, finite, and positive.

    Args:
        valor (Any): Value to validate.

    Returns:
        bool: True if the value is valid, False otherwise.

    Example:
        >>> valor_valido(100.50)
        True
        >>> valor_valido(-10)
        False
    """
    try:
        v = float(valor)
        return v > 0 and isfinite(v)
    except (ValueError, TypeError):
        return False

def ids_validos(*ids: Any) -> bool:
    """
    Checks if all provided IDs are positive integers.
    Also accepts numeric strings.

    Args:
        *ids (Any): List of IDs to validate.

    Returns:
        bool: True if all IDs are valid, False otherwise.

    Example:
        >>> ids_validos(1, "2", 3)
        True
        >>> ids_validos(1, -2, 3)
        False
    """
    try:
        return all(int(i) > 0 for i in ids)
    except (ValueError, TypeError):
        return False
