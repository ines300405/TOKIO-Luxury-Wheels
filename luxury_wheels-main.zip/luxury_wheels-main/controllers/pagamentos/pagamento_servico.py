"""
Service layer for payment business logic.

This module validates payment data and interacts with the repository (CRUD).
Provides functions to add, edit, delete, list, and export payments.
"""

import csv
import logging
from typing import List, Tuple, Dict, Union

from controllers.pagamentos.pagamento_validacao import data_valida, valor_valido, ids_validos
from controllers.pagamentos.pagamento_repositorio import (
    listar_pagamentos_bd,
    inserir_pagamento_bd,
    atualizar_pagamento_bd,
    remover_pagamento_bd,
)

logger = logging.getLogger(__name__)


def validar_dados_pagamento(dados: Dict[str, Union[str, int, float]]) -> Tuple[bool, str]:
    """
    Validates the provided payment data.

    Args:
        dados (Dict[str, Union[str, int, float]]): Dictionary containing the fields:
            - data_pagamento (str)
            - valor (float)
            - id_forma_pagamento (int)
            - id_reserva (int)

    Returns:
        Tuple[bool, str]: True if valid, False and error message otherwise.
    """
    if not data_valida(dados.get("data_pagamento", "")):
        return False, "Invalid date. Expected format: YYYY-MM-DD"

    if not valor_valido(dados.get("valor", 0)):
        return False, "Amount must be numeric and greater than zero."

    if not ids_validos(dados.get("id_forma_pagamento"), dados.get("id_reserva")):
        return False, "Payment method or reservation IDs are invalid or missing."

    return True, ""


def adicionar_pagamento(dados: Dict[str, str]) -> Tuple[bool, str]:
    """
    Adds a new payment after validating the data.

    Args:
        dados (Dict[str, str]): Dictionary with the payment fields.

    Returns:
        Tuple[bool, str]: True and success message, or False and error message.
    """
    valido, msg = validar_dados_pagamento(dados)
    if not valido:
        return False, msg

    # Convert to correct types
    dados_convertidos = {
        "id_reserva": int(dados["id_reserva"]),
        "id_forma_pagamento": int(dados["id_forma_pagamento"]),
        "valor": float(dados["valor"]),
        "data_pagamento": dados["data_pagamento"]
    }

    if inserir_pagamento_bd(dados_convertidos):
        return True, "Payment added successfully."
    return False, "Error adding payment."


def editar_pagamento(dados: Dict[str, str]) -> Tuple[bool, str]:
    """
    Updates an existing payment.

    Args:
        dados (Dict[str, str]): Dictionary with payment fields, including id_pagamento.

    Returns:
        Tuple[bool, str]: True and success message, or False and error message.
    """
    if not ids_validos(dados.get("id_pagamento")):
        return False, "Payment ID is required and must be valid."

    valido, msg = validar_dados_pagamento(dados)
    if not valido:
        return False, msg

    # Convert to correct types
    dados_convertidos = {
        "id_pagamento": int(dados["id_pagamento"]),
        "id_reserva": int(dados["id_reserva"]),
        "id_forma_pagamento": int(dados["id_forma_pagamento"]),
        "valor": float(dados["valor"]),
        "data_pagamento": dados["data_pagamento"]
    }

    if atualizar_pagamento_bd(dados_convertidos):
        return True, "Payment updated successfully."
    return False, "Error updating payment."


def excluir_pagamento(pagamento_id: int) -> bool:
    """
    Removes a payment by ID.

    Args:
        pagamento_id (int): ID of the payment to remove.

    Returns:
        bool: True if removed successfully, False otherwise.
    """
    if not ids_validos(pagamento_id):
        logger.warning("Invalid ID for payment removal.")
        return False
    return remover_pagamento_bd(pagamento_id)


def obter_pagamentos() -> List[Dict]:
    """
    Returns all payments registered in the database.

    Returns:
        List[Dict]: List of payments as dictionaries.
    """
    return listar_pagamentos_bd()


def exportar_pagamentos_para_csv(nome_arquivo: str = "pagamentos_export.csv") -> bool:
    """
    Exports all payments to a CSV file.

    Args:
        nome_arquivo (str): Destination CSV file name.

    Returns:
        bool: True if exported successfully, False otherwise.
    """
    pagamentos = obter_pagamentos()
    if not pagamentos:
        logger.warning("No payments found to export.")
        return False
    try:
        with open(nome_arquivo, mode='w', newline='', encoding='utf-8') as arquivo:
            escritor = csv.writer(arquivo)
            escritor.writerow(["Payment ID", "Reservation ID", "Payment Method ID", "Amount (€)", "Payment Date"])
            for pagamento in pagamentos:
                escritor.writerow([
                    pagamento["id"],
                    pagamento["id_reserva"],
                    pagamento["id_forma_pagamento"],
                    pagamento["valor"],
                    pagamento["data_pagamento"]
                ])
        logger.info("Payments exported successfully to %s", nome_arquivo)
        return True
    except Exception:
        logger.exception("Error exporting payments to CSV.")
        return False
