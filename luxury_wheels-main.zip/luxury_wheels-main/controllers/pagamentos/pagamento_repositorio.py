"""
Database access module for payments.

Contains CRUD functions for the 'Payments' table, including insertion, listing,
updating, removal, and search by ID.
"""

import logging
from typing import List, Optional, Dict
from controllers.utils_bd import obter_cursor

logger = logging.getLogger(__name__)


def inserir_pagamento_bd(dados: Dict) -> bool:
    """
    Inserts a new payment into the database.

    Args:
        dados (Dict): Dictionary with the required fields:
            - data_pagamento (str): Payment date.
            - valor (float): Payment amount.
            - id_forma_pagamento (int): ID of the payment method used.
            - id_reserva (int): ID of the associated reservation.

    Returns:
        bool: True if inserted successfully, False in case of error.
    """
    query = """
        INSERT INTO Pagamentos (data_pagamento, valor, id_forma_pagamento, id_reserva)
        VALUES (?, ?, ?, ?)
    """
    try:
        with obter_cursor(commit=True) as cursor:
            cursor.execute(query, (
                dados["data_pagamento"],
                float(dados["valor"]),
                int(dados["id_forma_pagamento"]),
                int(dados["id_reserva"])
            ))
        logger.info("Payment inserted successfully.")
        return True
    except Exception:
        logger.exception("Error inserting payment.")
        return False


def listar_pagamentos_bd() -> List[Dict]:
    """
    Lists all payments registered in the database.

    Returns:
        List[Dict]: List of dictionaries, each representing a payment
        with the fields: id, id_reserva, id_forma_pagamento, valor, data_pagamento.
    """
    query = """
        SELECT id, id_reserva, id_forma_pagamento, valor, data_pagamento
        FROM Pagamentos
        ORDER BY data_pagamento DESC
    """
    try:
        with obter_cursor() as cursor:
            cursor.execute(query)
            colunas = [desc[0] for desc in cursor.description]
            return [dict(zip(colunas, linha)) for linha in cursor.fetchall()]
    except Exception:
        logger.exception("Error fetching payments.")
        return []


def atualizar_pagamento_bd(dados: Dict) -> bool:
    """
    Updates an existing payment's data.

    Args:
        dados (Dict): Dictionary with the required fields:
            - id_pagamento (int): ID of the payment to update.
            - data_pagamento (str): New payment date.
            - valor (float): New amount.
            - id_forma_pagamento (int): New payment method.
            - id_reserva (int): New associated reservation.

    Returns:
        bool: True if updated successfully, False otherwise.
    """
    query = """
        UPDATE Pagamentos
        SET data_pagamento = ?, valor = ?, id_forma_pagamento = ?, id_reserva = ?
        WHERE id = ?
    """
    try:
        with obter_cursor(commit=True) as cursor:
            cursor.execute(query, (
                dados["data_pagamento"],
                float(dados["valor"]),
                int(dados["id_forma_pagamento"]),
                int(dados["id_reserva"]),
                int(dados["id_pagamento"])
            ))
            return cursor.rowcount > 0
    except Exception:
        logger.exception("Error updating payment.")
        return False


def remover_pagamento_bd(pagamento_id: int) -> bool:
    """
    Removes a payment from the database by ID.

    Args:
        pagamento_id (int): ID of the payment to remove.

    Returns:
        bool: True if removed successfully, False otherwise.
    """
    query = "DELETE FROM Pagamentos WHERE id = ?"
    try:
        with obter_cursor(commit=True) as cursor:
            cursor.execute(query, (pagamento_id,))
            return cursor.rowcount > 0
    except Exception:
        logger.exception("Error removing payment.")
        return False


def buscar_pagamento_por_id(pagamento_id: int) -> Optional[Dict]:
    """
    Searches for a specific payment by ID.

    Args:
        pagamento_id (int): ID of the payment to search.

    Returns:
        Optional[Dict]: Dictionary with the payment data, or None if not found.
    """
    query = """
        SELECT id, id_reserva, id_forma_pagamento, valor, data_pagamento
        FROM Pagamentos
        WHERE id = ?
    """
    try:
        with obter_cursor() as cursor:
            cursor.execute(query, (pagamento_id,))
            resultado = cursor.fetchone()
            if resultado:
                colunas = [desc[0] for desc in cursor.description]
                return dict(zip(colunas, resultado))
            return None
    except Exception:
        logger.exception("Error searching payment by ID.")
        return None
