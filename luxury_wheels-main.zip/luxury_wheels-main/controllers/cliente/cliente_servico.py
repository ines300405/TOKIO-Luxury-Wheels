"""
Customer service module.

This module implements the business logic (service layer),
acting as a bridge between the interface/controllers and the
customer repository in the database.

Main functions:
- create_customer: validates and inserts a new customer.
- edit_customer: updates an existing customer's data.
- delete_customer: removes a customer by ID.
- list_customers: returns a list of registered customers.
- find_customer_by_email: searches for a specific customer.
- save_customers_csv: exports customer data to CSV.
"""

import logging
from typing import Tuple, List, Optional, Dict
from controllers.cliente.cliente_validacoes import validar_dados_cliente
from controllers.cliente import cliente_repositorio

logger = logging.getLogger(__name__)

# -------------------- Serviços Públicos --------------------

def criar_cliente(nome: str, email: str, telefone: str, nif: str) -> Tuple[bool, str]:
    """
    Validates and creates a new customer.

Args:
    name (str): Customer's full name.
    email (str): Customer's unique email.
    phone (str): Contact phone number.
    tax_id (str): Tax identification number.

Returns:
    Tuple[bool, str]: Operation success and explanatory message.
    """
    valido, msg = validar_dados_cliente(nome, email, telefone, nif)
    if not valido:
        logger.warning("Validation failed while creating customer: %s", msg)
        return False, msg

    sucesso = cliente_repositorio.adicionar_cliente(nome, email, telefone, nif)
    if sucesso:
        logger.info("Customer '%s' successfully added.", nome)
        return True, "Customer successfully added."
    logger.warning("Customer '%s' could not be added (email already exists or error)).", nome)
    return False, "Customer could not be added: email already exists or database error."


def editar_cliente(id_cliente: int, nome: str, email: str, telefone: str, nif: str) -> Tuple[bool, str]:
    """
    Validates and updates an existing customer.

Args:
    customer_id (int): ID of the customer to be updated.
    name (str): New name.
    email (str): New email.
    phone (str): New phone number.
    tax_id (str): New tax ID.

Returns:
    Tuple[bool, str]: Operation success and explanatory message.
    """
    if not isinstance(id_cliente, int) or id_cliente <= 0:
        return False, "ID de cliente inválido."

    valido, msg = validar_dados_cliente(nome, email, telefone, nif)
    if not valido:
        logger.warning("Validation failed while editing customer ID %s: %s", id_cliente, msg)
        return False, msg

    sucesso = cliente_repositorio.atualizar_cliente(id_cliente, nome, email, telefone, nif)
    if sucesso:
        logger.info("Customer ID %s successfully updated.", id_cliente)
        return True, "Customer successfully updated."
    logger.warning("Customer ID %s not found or error while updating.", id_cliente)
    return False, "Error updating or customer not found."


def excluir_cliente(id_cliente: int) -> Tuple[bool, str]:
    """
    Removes an existing customer by ID.

Args:
    customer_id (int): Unique identifier of the customer.

Returns:
    Tuple[bool, str]: Operation success and message.
    """
    if not isinstance(id_cliente, int) or id_cliente <= 0:
        return False, "Invalid ID for deletion."

    sucesso = cliente_repositorio.remover_cliente(id_cliente)
    if sucesso:
        logger.info("Customer ID %s successfully removed.", id_cliente)
        return True, "Customer successfully removed."
    logger.warning("Error removing customer ID %s or customer not found.", id_cliente)
    return False, "Error removing customer or customer not found."


def listar_clientes() -> List[Dict]:
    """
    Lists all registered customers.

Returns:
    List[Dict]: List of dictionaries containing customer data.
    """
    clientes = cliente_repositorio.listar_clientes()
    logger.debug("Listing %d customers.", len(clientes))
    return clientes


def procurar_cliente_por_email(email: str) -> Optional[Dict]:
    """
    Searches for a customer by email.

Args:
    email (str): Customer's email.

Returns:
    Optional[Dict]: Customer data, if found.
    """
    if not isinstance(email, str) or not email.strip():
        logger.warning("Invalid email for search")
        return None
    cliente = cliente_repositorio.buscar_cliente_por_email(email)
    if cliente:
        logger.debug("Customer found by email '%s'.", email)
    else:
        logger.debug("No customer found with email '%s'.", email)
    return cliente


def salvar_clientes_csv(caminho: str = "clientes_export.csv") -> bool:
    """
    Exports all customers to a CSV file.

Args:
    path (str, optional): Output path of the CSV file.
        Defaults to "customers_export.csv".

Returns:
    bool: True if the export is successful, False otherwise.
    """
    sucesso = cliente_repositorio.exportar_clientes_para_csv(caminho)
    if sucesso:
        logger.info("Customers successfully exported to CSV: %s", caminho)
    else:
        logger.warning("Failed to export customers to CSV: %s", caminho)
    return sucesso
