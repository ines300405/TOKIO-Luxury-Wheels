"""
Customer management module.

This module provides functions to add, list, update, remove, and
export customers from the database. It also includes a function to search by email.

Main functions:
- add_customer: inserts a new customer (if the email does not already exist).
- list_customers: returns a list of all registered customers.
- update_customer: updates an existing customer's data.
- remove_customer: deletes a customer from the database.
- find_customer_by_email: searches for a customer by email.
- export_customers_to_csv: exports the customer list to a CSV file.
"""

import csv
import logging
from typing import List, Optional, Dict
from controllers.utils_bd import obter_cursor

logger = logging.getLogger(__name__)


def adicionar_cliente(nome: str, email: str, telefone: str, nif: str) -> bool:
    """
    Adds a new customer to the database if the email does not already exist.

Args:
    name (str): Customer's name.
    email (str): Customer's email (unique).
    phone (str): Customer's phone number.
    tax_id (str): Customer's tax identification number.

Returns:
    bool: True if the customer was added, False otherwise.
    """
    try:
        # Checks if a customer with the same email already exists
        existente = buscar_cliente_por_email(email)
        if existente:
            logger.warning("Customer with email '%s' already exists (ID %s).", email, existente["id"])
            return False

        with obter_cursor(commit=True) as cur:
            cur.execute(
                "INSERT INTO Clientes (nome, email, telefone, nif) VALUES (?, ?, ?, ?)",
                (nome.strip(), email.strip(), telefone.strip(), nif.strip())
            )
        return True
    except Exception:
        logger.exception("Error adding customer")
        return False


def listar_clientes() -> List[Dict]:
    """
    Lists all registered customers in the database.

Returns:
    List[Dict]: List of dictionaries containing customer data.
    """
    query = "SELECT id, nome, email, telefone, nif, data_registo FROM clientes ORDER BY id"
    try:
        with obter_cursor() as cursor:
            cursor.execute(query)
            linhas = cursor.fetchall()
            return [dict(linha) for linha in linhas] # each row is already like a dict
    except Exception as e:
        logger.exception("Error listing customers: %s", e)
        return []


def atualizar_cliente(id_cliente: int, nome: str, email: str, telefone: str, nif: str) -> bool:
    """
    Updates an existing customer's data.

Args:
    customer_id (int): ID of the customer to update.
    name (str): New customer name.
    email (str): New customer email.
    phone (str): New customer phone number.
    tax_id (str): New customer tax identification number.

Returns:
    bool: True if the customer was updated, False otherwise.
    """
    query = """
        UPDATE clientes SET nome = ?, email = ?, telefone = ?, nif = ? WHERE id = ?
    """
    try:
        with obter_cursor(commit=True) as cursor:
            cursor.execute(query, (nome.strip(), email.strip(), telefone.strip(), nif.strip(), id_cliente))
            atualizado = cursor.rowcount > 0
            logger.info("Customer ID %s updated: %s", id_cliente, atualizado)
            return atualizado
    except Exception as e:
        logger.exception("Error updating customer ID %s: %s", id_cliente, e)
        return False


def remover_cliente(id_cliente: int) -> bool:
    """
    Removes a customer from the database.

Args:
    customer_id (int): ID of the customer to remove.

Returns:
    bool: True if the customer was removed, False otherwise.
    """
    try:
        with obter_cursor() as cursor:
            cursor.execute("DELETE FROM clientes WHERE id = ?", (id_cliente,))
            removido = cursor.rowcount > 0
            logger.info("Customer ID %s removed: %s", id_cliente, removido)
            return removido
    except Exception as e:
        logger.exception("Error deleting customer ID %s: %s", id_cliente, e)
        return False


def buscar_cliente_por_email(email: str) -> Optional[Dict]:
    """
    Searches for a customer by their email.

Args:
    email (str): Email of the customer to search for.

Returns:
    Optional[Dict]: Dictionary with the customer's data, or None if not found.
    """
    try:
        with obter_cursor() as cur:
            cur.execute("SELECT id, nome, email, telefone, nif FROM Clientes WHERE email = ?", (email.strip(),))
            resultado = cur.fetchone()
            if resultado:
                colunas = [desc[0] for desc in cur.description]
                return dict(zip(colunas, resultado))
            return None
    except Exception:
        logger.exception("Error searching for customer by email")
        return None


def exportar_clientes_para_csv(caminho: str = "clientes_export.csv") -> bool:
    """
    Exports all customers to a CSV file.

Args:
    path (str, optional): Path of the CSV file to generate.
                          Defaults to 'customers_export.csv'.

Returns:
    bool: True if the export was successful, False otherwise.
    """
    clientes = listar_clientes()
    if not clientes:
        logger.warning("No customers to export")
        return False

    try:
        with open(caminho, mode="w", newline="", encoding="utf-8") as f:
            escritor = csv.DictWriter(f, fieldnames=["id", "nome", "email", "telefone", "nif", "data_registo"])
            escritor.writeheader()
            escritor.writerows(clientes)
        logger.info("Customers successfully exported to %s", caminho)
        return True
    except Exception as e:
        logger.exception("Error exporting CSV: %s", e)
        return False
