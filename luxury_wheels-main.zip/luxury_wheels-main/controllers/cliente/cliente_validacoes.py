"""
Customer data validation module.

Contains functions to check if user-provided fields
(name, email, phone, tax ID) follow the defined standards.

Main functions:
- valid_name: validates names (minimum 3 characters, letters and spaces only).
- valid_email: validates email format.
- valid_tax_id: validates tax ID with 9 digits.
- valid_phone: validates phone (numbers and symbols + - ( )).
- validate_customer_data: performs all validations together.
"""

import re
from typing import Tuple

# -------------------- Padrões de validação --------------------
PADRAO_EMAIL = re.compile(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$")
PADRAO_NIF = re.compile(r"^\d{9}$")
PADRAO_TELEFONE = re.compile(r"^[\d\s\+\-\(\)]{6,20}$")
PADRAO_NOME = re.compile(r"^[A-Za-zÀ-ÿ\s]{3,}$")

# -------------------- Validation Functions --------------------

def nome_valido(nome: str) -> Tuple[bool, str]:
    """
    Checks if the name is valid.

    Args:
        nome (str): Customer's name.

    Returns:
        Tuple[bool, str]:
            - True, "" if valid.
            - False, error message otherwise.
    """
    if not nome or not nome.strip():
        return False, "Name is required."
    if not PADRAO_NOME.match(nome.strip()):
        return False, "Invalid name: use letters and spaces, minimum 3 characters."
    return True, ""


def email_valido(email: str) -> Tuple[bool, str]:
    """
    Checks if the email is valid.

    Args:
        email (str): Email address.

    Returns:
        Tuple[bool, str]:
            - True, "" if valid.
            - False, error message otherwise.
    """
    if not email or not email.strip():
        return False, "Email is required."
    if not PADRAO_EMAIL.match(email.strip()):
        return False, "Invalid email."
    return True, ""


def nif_valido(nif: str) -> Tuple[bool, str]:
    """
    Checks if the tax ID (NIF) is valid.

    Args:
        nif (str): Tax ID number.

    Returns:
        Tuple[bool, str]:
            - True, "" if valid.
            - False, error message otherwise.
    """
    if not nif or not nif.strip():
        return False, "Tax ID is required."
    if not PADRAO_NIF.match(nif.strip()):
        return False, "Tax ID must contain exactly 9 numeric digits."
    return True, ""


def telefone_valido(telefone: str) -> Tuple[bool, str]:
    """
    Checks if the phone number is valid.

    Args:
        telefone (str): Phone number.

    Returns:
        Tuple[bool, str]:
            - True, "" if valid.
            - False, error message otherwise.
    """
    if not telefone or not telefone.strip():
        return False, "Phone number is required."
    if not PADRAO_TELEFONE.match(telefone.strip()):
        return False, "Invalid phone number. Use numbers and characters + - ( )"
    return True, ""


def validar_dados_cliente(nome: str, email: str, telefone: str, nif: str) -> Tuple[bool, str]:
    """
    Performs full validation of customer data.

    Args:
        nome (str): Customer's name.
        email (str): Customer's unique email.
        telefone (str): Phone number.
        nif (str): Tax ID number.

    Returns:
        Tuple[bool, str]:
            - True, "" if all fields are valid.
            - False, error message of the first invalid field.
    """
    for func in (nome_valido, email_valido, telefone_valido, nif_valido):
        valido, msg = func(locals()[func.__name__.split('_')[0]])
        if not valido:
            return False, msg
    return True, ""
