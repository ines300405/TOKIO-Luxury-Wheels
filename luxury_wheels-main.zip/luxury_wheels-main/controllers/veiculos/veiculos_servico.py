"""
Service layer for vehicle business logic.

Validates data and interacts with the repository.
"""

import logging
from controllers.veiculos import veiculos_validacoes, veiculos_repositorio

logger = logging.getLogger(__name__)

# -------------------- Public Services --------------------

def obter_veiculos_servico() -> list:
    """
    Returns all registered vehicles.

    Returns:
        list: List of dictionaries containing vehicles
    """
    return veiculos_repositorio.listar_veiculos_bd()


def adicionar_veiculo_servico(**dados) -> int | None:
    """
    Validates and inserts a vehicle into the database.

    Args:
        **dados: Vehicle fields

    Returns:
        int | None: ID of inserted vehicle or None on error
    """
    # Clean string data
    dados = {chave: valor.strip().replace("\n", "") if isinstance(valor, str) else valor
             for chave, valor in dados.items()}

    # Set default image if not provided
    dados.setdefault("imagem", "")

    if not _validar_veiculo(dados, incluir_id=False):
        logger.error("Validation failed when adding vehicle: %s", dados)
        return None

    dados.setdefault("km_atual", 0)
    dados.setdefault("estado", "disponível")
    veiculo_id = veiculos_repositorio.inserir_veiculo_bd(dados)
    if veiculo_id:
        logger.info("Vehicle inserted with ID %s", veiculo_id)
    else:
        logger.error("Failed to insert vehicle into the database.")
    return veiculo_id


def atualizar_veiculo_servico(veiculo_id: int, **dados) -> bool:
    """
    Validates and updates an existing vehicle.

    Args:
        veiculo_id (int): Vehicle ID
        **dados: Updated vehicle fields

    Returns:
        bool: True if updated successfully, False otherwise
    """
    if not veiculos_validacoes.validar_inteiro(veiculo_id, 1):
        logger.error("Invalid ID for update.")
        return False

    # Clean string data
    dados = {chave: valor.strip().replace("\n", "") if isinstance(valor, str) else valor
             for chave, valor in dados.items()}

    dados_atualizados = dados.copy()
    dados_atualizados.setdefault("km_atual", 0)
    dados_atualizados.setdefault("estado", "disponível")
    dados_atualizados.setdefault("imagem", "")
    dados_atualizados["id"] = veiculo_id

    if not _validar_veiculo(dados_atualizados, incluir_id=True):
        logger.error("Data validation failed for update: %s", dados_atualizados)
        return False

    return veiculos_repositorio.atualizar_veiculo_bd(dados_atualizados)


def remover_veiculo_servico(veiculo_id: int) -> bool:
    """
    Removes a vehicle by ID.

    Args:
        veiculo_id (int): Vehicle ID

    Returns:
        bool: True if removed successfully
    """
    if not veiculos_validacoes.validar_inteiro(veiculo_id, 1):
        return False
    return veiculos_repositorio.remover_veiculo_bd(veiculo_id)


def marcar_veiculo_manutencao_servico(veiculo_id: int) -> bool:
    """
    Marks a vehicle as under maintenance.

    Args:
        veiculo_id (int): Vehicle ID

    Returns:
        bool: True if marked successfully
    """
    if not veiculos_validacoes.validar_inteiro(veiculo_id, 1):
        return False
    return veiculos_repositorio.marcar_veiculo_manutencao_bd(veiculo_id)


def exportar_veiculos_servico(caminho: str = "veiculos_export.csv") -> bool:
    """
    Exports all vehicles to a CSV file.

    Args:
        caminho (str): CSV file path

    Returns:
        bool: True if exported successfully
    """
    return veiculos_repositorio.exportar_veiculos_para_csv(caminho)


# -------------------- Helper Methods --------------------

def _validar_veiculo(d: dict, incluir_id=False) -> bool:
    """
    Validates vehicle fields.

    Args:
        d (dict): Vehicle data
        incluir_id (bool): If True, also validates the ID

    Returns:
        bool: True if all fields are valid
    """
    validacoes = [
        veiculos_validacoes.validar_texto(d.get("marca")),
        veiculos_validacoes.validar_texto(d.get("modelo")),
        veiculos_validacoes.validar_texto(d.get("matricula")),
        veiculos_validacoes.validar_inteiro(d.get("ano"), 1900),
        veiculos_validacoes.validar_texto(d.get("categoria")),
        veiculos_validacoes.validar_texto(d.get("transmissao")),
        veiculos_validacoes.validar_texto(d.get("tipo")),
        veiculos_validacoes.validar_inteiro(d.get("lugares"), 1),
        True if not d.get("imagem") else veiculos_validacoes.validar_texto(d.get("imagem")),
        veiculos_validacoes.validar_decimal(d.get("diaria"), 0),
        veiculos_validacoes.validar_data(d.get("data_ultima_revisao")),
        veiculos_validacoes.validar_data(d.get("data_proxima_revisao")),
        veiculos_validacoes.validar_data(d.get("data_ultima_inspecao")),
        veiculos_validacoes.validar_data(d.get("data_proxima_inspecao")),
    ]
    if incluir_id:
        validacoes.append(veiculos_validacoes.validar_inteiro(d.get("id"), 1))

    return all(validacoes)


def _preparar_valores_para_insercao(d: dict) -> tuple:
    """Prepares vehicle values for database insertion."""
    return (
        d["marca"].strip(), d["modelo"].strip(), d["matricula"].strip(),
        int(d["ano"]), d.get("km_atual", 0),
        d["data_ultima_revisao"], d["data_proxima_revisao"],
        d["categoria"].strip(), d["transmissao"].strip(), d["tipo"].strip(),
        int(d["lugares"]), d["imagem"].strip(), float(d["diaria"]),
        d["data_ultima_inspecao"], d["data_proxima_inspecao"],
        "disponível"
    )


def _preparar_valores_para_atualizacao(veiculo_id: int, d: dict) -> tuple:
    """Prepares vehicle values for database update."""
    return (
        d["marca"].strip(), d["modelo"].strip(), d["matricula"].strip(),
        int(d["ano"]), d.get("km_atual", 0),
        d["data_ultima_revisao"], d["data_proxima_revisao"],
        d["categoria"].strip(), d["transmissao"].strip(), d["tipo"].strip(),
        int(d["lugares"]), d["imagem"].strip(), float(d["diaria"]),
        d["data_ultima_inspecao"], d["data_proxima_inspecao"],
        int(veiculo_id)
    )
