from datetime import datetime

def validar_texto(texto: str, minimo: int = 1) -> bool:

    """
    Checks if the provided value is a non-empty string with a minimum length.

    Args:
        value (str): Text to validate.
        minimum (int): Minimum length of the text (default=1).

    Returns:
        bool: True if valid text, False otherwise.
    """
    return isinstance(texto, str) and len(texto.strip()) >= minimo



def validar_inteiro(valor, minimo: int = 0) -> bool:

    """
    Validates if the provided value is an integer greater than or equal to a minimum.

    Args:
        value: Value to validate (can be int, str, etc.).
        minimum (int): Minimum allowed value (default=0).

    Returns:
        bool: True if integer >= minimum, False otherwise.
    """
    try:
        return int(valor) >= minimo
    except (ValueError, TypeError):
        return False


def validar_decimal(valor, minimo: float = 0.0) -> bool:

    """
    Validates if the provided value is a decimal number greater than or equal to a minimum.

    Args:
        value: Value to validate (can be float, int, str, etc.).
        minimum (float): Minimum allowed value (default=0.0).

    Returns:
        bool: True if decimal >= minimum, False otherwise.
    """
    try:
        return float(valor) >= minimo
    except (ValueError, TypeError):
        return False


def validar_data(data_str: str, formato: str = "%Y-%m-%d") -> bool:

    """
    Validates if the provided string represents a valid date in the specified format.

    Args:
        date_str (str): Date string to validate.
        format_str (str): Expected date format (default="%Y-%m-%d").

    Returns:
        bool: True if the date is valid in the specified format, False otherwise.
    """
    if data_str is None or (isinstance(data_str, str) and data_str.strip() == ""):
        # Treat empty/None as valid (optional date)
        return True
    try:
        datetime.strptime(data_str, formato)
        return True
    except (ValueError, TypeError):
        return False
