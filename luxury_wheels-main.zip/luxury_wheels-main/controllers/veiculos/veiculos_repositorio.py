"""
Database access module for vehicles.

Includes CRUD functions, maintenance marking, and CSV export.
"""

import logging
import csv
from typing import List, Dict, Optional
from db.conexao import conectar_base_dados
from controllers.utils_bd import obter_cursor

logger = logging.getLogger(__name__)

def listar_veiculos_bd() -> List[Dict]:
    """
    Returns all vehicles registered in the database.

    Returns:
        List[Dict]: List of dictionaries containing vehicle data
    """
    sql = "SELECT * FROM Veiculos ORDER BY id"
    try:
        with obter_cursor() as cursor:
            cursor.execute(sql)
            colunas = [desc[0] for desc in cursor.description]
            return [dict(zip(colunas, linha)) for linha in cursor.fetchall()]
    except Exception:
        logger.exception("Error fetching vehicles.")
        return []

def buscar_veiculo_por_id(veiculo_id: int) -> Optional[Dict]:
    """
    Fetches a vehicle by ID.

    Args:
        vehicle_id (int): Vehicle ID

    Returns:
        Optional[Dict]: Dictionary with vehicle data or None if not found
    """
    sql = "SELECT * FROM Veiculos WHERE id = ?"
    try:
        with obter_cursor() as cursor:
            cursor.execute(sql, (veiculo_id,))
            resultado = cursor.fetchone()
            if resultado:
                colunas = [desc[0] for desc in cursor.description]
                return dict(zip(colunas, resultado))
            return None
    except Exception:
        logger.exception("Error fetching vehicle by ID.")
        return None

def inserir_veiculo_bd(dados: dict) -> Optional[int]:

    """
    Inserts a new vehicle into the database.

    Args:
        data (dict): Dictionary with vehicle data

    Returns:
        Optional[int]: Inserted vehicle ID or None on error
    """
    sql = """
        INSERT INTO Veiculos (marca, modelo, matricula, ano, km_atual,
                              data_ultima_revisao, data_proxima_revisao, categoria,
                              transmissao, tipo, lugares, imagem, diaria,
                              data_ultima_inspecao, data_proxima_inspecao, estado)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
    try:
        with obter_cursor(commit=True) as cur:
            cur.execute(sql, (
                dados["marca"].strip(),
                dados["modelo"].strip(),
                dados["matricula"].strip(),
                int(dados["ano"]),
                dados.get("km_atual", 0),
                dados["data_ultima_revisao"],
                dados["data_proxima_revisao"],
                dados["categoria"].strip(),
                dados["transmissao"].strip(),
                dados["tipo"].strip(),
                int(dados["lugares"]),
                dados["imagem"].strip(),
                float(dados["diaria"]),
                dados["data_ultima_inspecao"],
                dados["data_proxima_inspecao"],
                dados.get("estado", "disponível")
            ))
            return cur.lastrowid
    except Exception:
        logger.exception("Error inserting vehicle")
        return None

def atualizar_veiculo_bd(dados: dict) -> bool:

    """
    Updates an existing vehicle.

    Args:
        data (dict): Dictionary with updated vehicle data (must contain 'id')

    Returns:
        bool: True if updated successfully, False otherwise
    """
    conn = conectar_base_dados()
    cur = conn.cursor()
    try:
        sql = """
            UPDATE Veiculos
            SET marca = ?, modelo = ?, matricula = ?, ano = ?, km_atual = ?,
                data_ultima_revisao = ?, data_proxima_revisao = ?, categoria = ?,
                transmissao = ?, tipo = ?, lugares = ?, imagem = ?, diaria = ?,
                data_ultima_inspecao = ?, data_proxima_inspecao = ?, estado = ?
            WHERE id = ?
            """
        parametros = (
            dados["marca"].strip(),
            dados["modelo"].strip(),
            dados["matricula"].strip(),
            int(dados["ano"]),
            dados.get("km_atual", 0),
            dados["data_ultima_revisao"],
            dados["data_proxima_revisao"],
            dados["categoria"].strip(),
            dados["transmissao"].strip(),
            dados["tipo"].strip(),
            int(dados["lugares"]),
            dados["imagem"].strip(),
            float(dados["diaria"]),
            dados["data_ultima_inspecao"],
            dados["data_proxima_inspecao"],
            dados.get("estado", "disponível"),
            int(dados["id"])
        )

        logger.debug("UPDATE vehicle ID %s with data: %s", dados.get("id"), dados)
        cur.execute(sql, parametros)
        conn.commit()
        logger.debug("Rows affected by UPDATE: %s", cur.rowcount)

        return cur.rowcount > 0
    except Exception as e:
        logger.error(f"Error updating vehicle: {e}")
        return False
    finally:
        conn.close()

def remover_veiculo_bd(veiculo_id: int) -> bool:

    """
    Removes a vehicle by ID.

    Args:
        vehicle_id (int): Vehicle ID to remove

    Returns:
        bool: True if removed successfully, False otherwise
    """
    sql = "DELETE FROM Veiculos WHERE id=?"
    try:
        with obter_cursor(commit=True) as cursor:
            cursor.execute(sql, (veiculo_id,))
        return cursor.rowcount > 0
    except Exception:
        logger.exception("Error removing vehicle.")
        return False

def marcar_veiculo_manutencao_bd(veiculo_id: int) -> bool:

    """
    Marks a vehicle as 'Under Maintenance'.

    Args:
        vehicle_id (int): Vehicle ID

    Returns:
        bool: True if marked successfully, False otherwise
    """
    try:
        conexao = conectar_base_dados()
        if conexao is None:
            logger.error("Could not connect to the database.")
            return False

        cursor = conexao.cursor()
        cursor.execute(
            "UPDATE Veiculos SET estado = 'Manutenção' WHERE id = ?",
            (veiculo_id,)
        )
        conexao.commit()
        cursor.close()
        conexao.close()
        logger.info("Vehicle ID %s marked as under maintenance.", veiculo_id)
        return True
    except Exception:
        logger.exception("Error marking maintenance for vehicle ID %s.", veiculo_id)
        return False

def exportar_veiculos_para_csv(caminho: str = "veiculos_export.csv") -> bool:

    """
    Exports all vehicles to a CSV file.

    Args:
        path (str): CSV file path

    Returns:
        bool: True if exported successfully, False otherwise
    """
    lista = listar_veiculos_bd()
    if not lista:
        return False
    try:
        with open(caminho, "w", newline="", encoding="utf-8") as f:
            escritor = csv.DictWriter(f, fieldnames=lista[0].keys())
            escritor.writeheader()
            escritor.writerows(lista)
        return True
    except Exception:
        logger.exception("Error exporting vehicles.")
        return False
