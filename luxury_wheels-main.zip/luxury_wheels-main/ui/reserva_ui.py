import tkinter as tk
from tkinter import ttk, messagebox
from utils.tooltip import DicaFerramenta
from datetime import datetime
from controllers.reservas.reservas_repositorio import obter_diaria_veiculo
from controllers.reservas.reservas_servico import (
    adicionar_reserva_servico,
    atualizar_reserva_servico,
    excluir_reserva_servico,
    exportar_reservas_para_csv,
    obter_reservas_servico
)
from controllers.reservas.reservas_validacoes import validar_periodo, validar_ids

DATE_FORMAT = "%Y-%m-%d"
RESERVATION_FIELDS = ["Reservation ID", "Client ID", "Vehicle ID", "Start Date", "End Date", "Value"]


class AplicacaoReserva(ttk.Frame):
    """Graphical interface for vehicle reservation management."""

    def __init__(self, master: tk.Tk):
        super().__init__(master, padding=10)
        master.title("Reservation Management")
        master.geometry("700x500")
        master.resizable(True, True)
        self.pack(fill=tk.BOTH, expand=True)

        self.vars = {}  # StringVars para os campos
        self.fields = {}  # Entry widgets

        self._build_form()
        self._build_buttons()
        self._build_table()
        self._load_table()

        # Observadores para atualizar automaticamente o valor
        self.vars["Vehicle ID"].trace_add("write", lambda *args: self._auto_calculate_value())
        self.vars["Start Date"].trace_add("write", lambda *args: self._auto_calculate_value())
        self.vars["End Date"].trace_add("write", lambda *args: self._auto_calculate_value())

    def _build_form(self):
        frame = ttk.LabelFrame(self, text="Reservation Data", padding=10)
        frame.pack(fill=tk.X, pady=5)

        editable_map = [False, True, True, True, True, False]

        for i, (field, editable) in enumerate(zip(RESERVATION_FIELDS, editable_map)):
            ttk.Label(frame, text=f"{field}:").grid(row=i, column=0, sticky=tk.E, padx=5, pady=4)

            var = tk.StringVar()
            entry = ttk.Entry(frame, textvariable=var, width=30)
            entry.grid(row=i, column=1, sticky=tk.W, padx=5, pady=4)

            if not editable:
                entry.state(["readonly"])
            else:
                DicaFerramenta(entry, field)

            self.fields[field] = entry
            self.vars[field] = var

    def _build_buttons(self):
        button_frame = ttk.Frame(self)
        button_frame.pack(fill=tk.X, pady=5)
        ttk.Button(button_frame, text="Add", command=self.add_reservation).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Update", command=self.update_reservation).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Remove", command=self.remove_reservation).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Clear", command=self.clear_form).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Export CSV", command=self.export_reservations).pack(side=tk.RIGHT, padx=5)

    def _build_table(self):
        table_frame = ttk.Frame(self)
        table_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        columns = ("ID", "Client", "Vehicle", "Start", "End", "Value")
        self.table = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="browse")
        for col in columns:
            self.table.heading(col, text=col)
            self.table.column(col, width=100, anchor=tk.CENTER)

        scroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.table.yview)
        self.table.configure(yscroll=scroll.set)
        self.table.grid(row=0, column=0, sticky="nsew")
        scroll.grid(row=0, column=1, sticky="ns")

        table_frame.rowconfigure(0, weight=1)
        table_frame.columnconfigure(0, weight=1)
        self.table.bind("<<TreeviewSelect>>", self._select_reservation)

    def _load_table(self):
        """Carrega a tabela com todas as reservas, garantindo que o valor esteja sempre presente."""
        self.table.delete(*self.table.get_children())
        for reservation in obter_reservas_servico():
            # Calcular valor caso não exista
            total = reservation.get("valor_total") or reservation.get("total_amount")
            if total is None:
                total = self.calcular_valor_reserva(
                    reservation["id_veiculo"],
                    reservation["data_inicio"],
                    reservation["data_fim"]
                )
            values = (
                reservation["id"],
                reservation["id_cliente"],
                reservation["id_veiculo"],
                reservation["data_inicio"],
                reservation["data_fim"],
                f"{total:.2f}"
            )
            self.table.insert("", tk.END, values=values)

    def _select_reservation(self, _):
        selected = self.table.selection()
        if not selected:
            return
        values = self.table.item(selected[0], "values")
        for i, field in enumerate(RESERVATION_FIELDS):
            entry = self.fields[field]
            entry.state(["!readonly"])
            entry.delete(0, tk.END)
            entry.insert(0, values[i])
            if field in ["Reservation ID", "Value"]:
                entry.state(["readonly"])
        self._auto_calculate_value()

    def clear_form(self):
        for field, entry in self.fields.items():
            entry.state(["!readonly"])
            entry.delete(0, tk.END)
            if field in ["Reservation ID", "Value"]:
                entry.state(["readonly"])
        self.table.selection_remove(self.table.selection())

    def _validate_reservation_fields(self, include_id=False) -> dict | None:
        try:
            client_id = int(self.vars["Client ID"].get())
            vehicle_id = int(self.vars["Vehicle ID"].get())
            start_date = self.vars["Start Date"].get().strip()
            end_date = self.vars["End Date"].get().strip()
        except ValueError:
            messagebox.showerror("Error", "All numeric fields must contain valid values.")
            return None

        if not start_date or not end_date:
            messagebox.showwarning("Warning", "Please fill in both start and end dates.")
            return None

        if not validar_periodo(start_date, end_date):
            messagebox.showerror("Error", "Dates are invalid or out of order.")
            return None

        ids_to_validate = (client_id, vehicle_id)
        reservation_id = None
        if include_id:
            try:
                reservation_id = int(self.vars["Reservation ID"].get())
                ids_to_validate = (reservation_id, client_id, vehicle_id)
            except ValueError:
                messagebox.showerror("Error", "Invalid reservation ID.")
                return None

        if not validar_ids(*ids_to_validate):
            messagebox.showerror("Error", "IDs must be positive integers.")
            return None

        total_amount = self.calcular_valor_reserva(vehicle_id, start_date, end_date)
        self.vars["Value"].set(f"{total_amount:.2f}")

        return {
            "reservation_id": reservation_id,
            "start_date": start_date,
            "end_date": end_date,
            "client_id": client_id,
            "vehicle_id": vehicle_id,
            "status": "Reserved",
            "total_amount": total_amount
        }

    def add_reservation(self):
        data = self._validate_reservation_fields()
        if not data:
            return

        existing_ids = [r["id"] for r in obter_reservas_servico() if r.get("id")]
        new_id = 1
        while new_id in existing_ids:
            new_id += 1
        data["reservation_id"] = new_id

        if adicionar_reserva_servico(
            cliente_id=data["client_id"],
            veiculo_id=data["vehicle_id"],
            data_inicio=data["start_date"],
            data_fim=data["end_date"],
            status=data["status"],
            valor_total=data["total_amount"]
        ):
            messagebox.showinfo("Success", f"Reservation successfully added (ID {new_id}).")
            self.clear_form()
            self._load_table()
        else:
            messagebox.showerror("Error", "Failed to add reservation.")

    def update_reservation(self):
        data = self._validate_reservation_fields(include_id=True)
        if not data:
            return
        success = atualizar_reserva_servico(
            reserva_id=data["reservation_id"],
            data_inicio=data["start_date"],
            data_fim=data["end_date"],
            cliente_id=data["client_id"],
            veiculo_id=data["vehicle_id"],
            status=data["status"],
            valor_total=data["total_amount"]
        )
        if success:
            messagebox.showinfo("Success", "Reservation successfully updated.")
            self.clear_form()
            self._load_table()
        else:
            messagebox.showerror("Error", "Failed to update reservation.")

    def remove_reservation(self):
        reservation_id = self.vars["Reservation ID"].get()
        if not reservation_id or not reservation_id.isdigit():
            messagebox.showerror("Error", "Select a valid reservation to remove.")
            return
        if messagebox.askyesno("Confirm", "Do you really want to remove this reservation?"):
            if excluir_reserva_servico(int(reservation_id)):
                messagebox.showinfo("Success", "Reservation successfully removed.")
                self.clear_form()
                self._load_table()
            else:
                messagebox.showerror("Error", "Failed to remove reservation.")

    def export_reservations(self):
        if exportar_reservas_para_csv():
            messagebox.showinfo("Success", "Reservations successfully exported.")
        else:
            messagebox.showerror("Error", "Failed to export reservations.")

    def calcular_valor_reserva(self, veiculo_id: int, inicio: str, fim: str) -> float:
        try:
            diaria = obter_diaria_veiculo(veiculo_id)
            dias = (datetime.strptime(fim, DATE_FORMAT) - datetime.strptime(inicio, DATE_FORMAT)).days + 1
            return diaria * dias if dias > 0 else 0.0
        except Exception:
            return 0.0

    def _auto_calculate_value(self, *_):
        """Automatically calculates reservation value in real time."""
        try:
            vehicle_id = int(self.vars["Vehicle ID"].get())
            start_date = self.vars["Start Date"].get().strip()
            end_date = self.vars["End Date"].get().strip()
            if start_date and end_date:
                total = self.calcular_valor_reserva(vehicle_id, start_date, end_date)
                self.vars["Value"].set(f"{total:.2f}")
        except ValueError:
            self.vars["Value"].set("0.00")


if __name__ == "__main__":
    root = tk.Tk()
    app = AplicacaoReserva(root)
    root.mainloop()
