import tkinter as tk
from tkinter import ttk, messagebox
from utils.tooltip import DicaFerramenta
from controllers.pagamentos.pagamento_servico import (
    adicionar_pagamento,
    editar_pagamento,
    excluir_pagamento,
    exportar_pagamentos_para_csv,
    obter_pagamentos
)

class AplicacaoPagamentos(ttk.Frame):
    """
    Tkinter application for managing payments.

    Allows adding, updating, removing, listing, and exporting payments
    using a graphical interface with form and table.
    """

    def __init__(self, master: tk.Tk):
        """
        Initializes the payment application.

        Args:
            master (tk.Tk): Main application window.
        """
        super().__init__(master, padding=10)
        master.title("Payments Management")
        master.geometry("700x560")
        master.resizable(True, True)
        self.pack(fill=tk.BOTH, expand=True)

        self.input_fields = {}
        self._set_style()
        ttk.Label(self, text="Payments Management", font=("Segoe UI", 16, "bold")).pack(pady=(0, 10))
        self._build_form()
        self._build_buttons()
        self._build_table()
        self._load_table()

    def _set_style(self):
        """
        Sets the style for ttk widgets, including buttons and Treeview headers.
        """
        style = ttk.Style()
        style.configure("TButton", padding=6)
        style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"))
        style.map("Treeview", background=[("selected", "#ececec")])

    def _build_form(self):
        """
        Builds the payment data entry form.
        Creates fields: Payment ID, Reservation ID, Payment Method ID, Amount, Payment Date.
        """
        form_frame = ttk.LabelFrame(self, text="Payment Data", padding=10)
        form_frame.pack(fill=tk.X, pady=5)

        fields = [
            ("Payment ID", False),
            ("Reservation ID", True),
            ("Payment Method ID", True),
            ("Amount (€)", True),
            ("Payment Date", True),
        ]

        for i, (label_text, editable) in enumerate(fields):
            col = i % 2
            row = i // 2
            ttk.Label(form_frame, text=f"{label_text}:").grid(row=row, column=col * 2, sticky=tk.E, padx=5, pady=4)
            entry = ttk.Entry(form_frame, width=30)
            entry.grid(row=row, column=col * 2 + 1, sticky=tk.W, padx=5, pady=4)

            if not editable:
                entry.state(["readonly"])
            else:
                DicaFerramenta(entry, label_text)

            self.input_fields[label_text] = entry

        for i in range(4):
            form_frame.columnconfigure(i, weight=1)

    def _build_buttons(self):
        """
        Creates action buttons: Add, Update, Remove, Clear, and Export CSV.
        """
        buttons_frame = ttk.Frame(self)
        buttons_frame.pack(fill=tk.X, pady=5)

        ttk.Button(buttons_frame, text="Add", command=self._action_add).pack(side=tk.LEFT, padx=5)
        ttk.Button(buttons_frame, text="Update", command=self._action_update).pack(side=tk.LEFT, padx=5)
        ttk.Button(buttons_frame, text="Remove", command=self._action_remove).pack(side=tk.LEFT, padx=5)
        ttk.Button(buttons_frame, text="Clear", command=self._clear_form).pack(side=tk.LEFT, padx=5)
        ttk.Button(buttons_frame, text="Export CSV", command=self._action_export_csv).pack(side=tk.RIGHT, padx=5)

    def _build_table(self):
        """
        Builds the Treeview table listing all registered payments.
        """
        table_frame = ttk.LabelFrame(self, text="Registered Payments", padding=5)
        table_frame.pack(fill=tk.BOTH, expand=True, pady=(5, 10))

        columns = ("id", "reservation", "method", "amount", "date")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings")

        headers = {
            "id": "Payment ID",
            "reservation": "Reservation ID",
            "method": "Payment Method ID",
            "amount": "Amount (€)",
            "date": "Payment Date"
        }

        for col in columns:
            self.tree.heading(col, text=headers[col])
            self.tree.column(col, anchor=tk.CENTER, width=130)

        self.tree.tag_configure("even_row", background="#f2f2f2")
        self.tree.tag_configure("odd_row", background="#ffffff")

        scroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscroll=scroll.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        scroll.grid(row=0, column=1, sticky="ns")

        table_frame.rowconfigure(0, weight=1)
        table_frame.columnconfigure(0, weight=1)

        self.tree.bind("<<TreeviewSelect>>", self._fill_form)

    def _fill_form(self, _):
        """
        Fills the form with the payment data selected in the Treeview.

        Args:
            _ : Selection event (not used directly).
        """
        selected = self.tree.selection()
        if not selected:
            return
        values = self.tree.item(selected[0], "values")
        for i, field in enumerate(self.input_fields):
            entry = self.input_fields[field]
            entry.state(["!readonly"])
            entry.delete(0, tk.END)
            entry.insert(0, values[i])
            if field == "Payment ID":
                entry.state(["readonly"])

    def _get_form_data(self):
        """
        Retrieves the data entered in the form.

        Returns:
            dict: Payment data.
        """
        return {
            "payment_id": self.input_fields["Payment ID"].get().strip(),
            "reservation_id": self.input_fields["Reservation ID"].get().strip(),
            "payment_method_id": self.input_fields["Payment Method ID"].get().strip(),
            "amount": self.input_fields["Amount (€)"].get().strip(),
            "payment_date": self.input_fields["Payment Date"].get().strip(),
        }

    def _action_add(self):
        """
        Adds a new payment using the form data.
        Displays success or error messages.
        """
        data = self._get_form_data()
        success, msg = adicionar_pagamento(data)
        if success:
            messagebox.showinfo("Success", msg)
            self._clear_form()
            self._load_table()
        else:
            messagebox.showerror("Error", msg)

    def _action_update(self):
        """
        Updates an existing payment using the form data.
        Displays success or error messages.
        """
        data = self._get_form_data()
        success, msg = editar_pagamento(data)
        if success:
            messagebox.showinfo("Success", msg)
            self._clear_form()
            self._load_table()
        else:
            messagebox.showerror("Error", msg)

    def _action_remove(self):
        """
        Removes the selected payment after user confirmation.
        """
        payment_id = self.input_fields["Payment ID"].get().strip()
        if not payment_id.isdigit():
            messagebox.showerror("Error", "Select a valid ID to remove.")
            return
        if messagebox.askyesno("Confirm", "Do you really want to remove this payment?"):
            if excluir_pagamento(int(payment_id)):
                messagebox.showinfo("Success", "Payment removed successfully.")
                self._clear_form()
                self._load_table()
            else:
                messagebox.showerror("Error", "Failed to remove payment.")

    def _load_table(self):
        """
        Loads the payment list into the Treeview.
        """
        self.tree.delete(*self.tree.get_children())
        for i, payment in enumerate(obter_pagamentos()):
            values = (
                payment["id"],
                payment["id_reserva"],
                payment["id_forma_pagamento"],
                payment["valor"],
                payment["data_pagamento"],
            )
            tag = "even_row" if i % 2 == 0 else "odd_row"
            self.tree.insert("", tk.END, values=values, tags=(tag,))

    def _clear_form(self):
        """
        Clears all form fields and sets Payment ID as readonly.
        """
        for field, entry in self.input_fields.items():
            entry.state(["!readonly"])
            entry.delete(0, tk.END)
            if field == "Payment ID":
                entry.state(["readonly"])

    def _action_export_csv(self):
        """
        Exports payments to CSV and displays success or error messages.
        """
        if exportar_pagamentos_para_csv():
            messagebox.showinfo("Success", "Payments exported successfully.")
        else:
            messagebox.showerror("Error", "Failed to export payments.")


if __name__ == "__main__":
    root = tk.Tk()
    app = AplicacaoPagamentos(root)
    root.mainloop()
