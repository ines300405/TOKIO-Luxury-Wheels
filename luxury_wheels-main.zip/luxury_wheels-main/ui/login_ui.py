import tkinter as tk
from tkinter import messagebox
from controllers.utilizadores.utilizador_controller import criar_utilizador, verificar_login


def abrir_login(on_success):
    """Opens the login window. on_success is the function called to open the main app."""

    def login():
        """Handles user login."""
        user = verificar_login(entry_email.get(), entry_pass.get())
        if user:
            messagebox.showinfo("Welcome", f"Hello, {user[1]} ({user[2]})")
            root.destroy()
            on_success(user)  # Calls the function to open the rest of the app
        else:
            messagebox.showerror("Error", "Invalid credentials")

    def registar():
        """Handles user registration."""
        if criar_utilizador(entry_nome.get(), entry_email.get(), entry_pass.get()):
            messagebox.showinfo("Success", "User registered successfully!")
        else:
            messagebox.showerror("Error", "Email already exists")

    root = tk.Tk()
    root.title("Login Luxury Wheels")

    tk.Label(root, text="Nome").grid(row=0, column=0)
    entry_nome = tk.Entry(root)
    entry_nome.grid(row=0, column=1)

    tk.Label(root, text="Email").grid(row=1, column=0)
    entry_email = tk.Entry(root)
    entry_email.grid(row=1, column=1)

    tk.Label(root, text="Senha").grid(row=2, column=0)
    entry_pass = tk.Entry(root, show="*")
    entry_pass.grid(row=2, column=1)

    tk.Button(root, text="Login", command=login).grid(row=3, column=0, pady=5)
    tk.Button(root, text="Registar", command=registar).grid(row=3, column=1, pady=5)

    root.mainloop()
