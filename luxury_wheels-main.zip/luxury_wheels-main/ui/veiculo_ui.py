import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from PIL import Image, ImageTk
import os
from controllers.veiculos import veiculos_servico  # Ensure this module exists


# Absolute path to photo_cars folder
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PHOTO_DIR = os.path.join(BASE_DIR, "photo_cars")


class AplicacaoVeiculo(ttk.Frame):
    """Main application class for vehicle management."""

    def __init__(self, mestre: tk.Tk):
        super().__init__(mestre, padding=10)
        mestre.title("Gestão de Veículos")
        mestre.geometry("1200x600")
        self.pack(fill=tk.BOTH, expand=True)

        self.id_selecionado = None
        self.img_atual = None
        self.formulario = None

        # Configure 3 columns: lista | formulario | imagem
        self.grid_columnconfigure(0, weight=3)  # Treeview
        self.grid_columnconfigure(1, weight=5)  # Form
        self.grid_columnconfigure(2, weight=4)  # Imagem
        self.grid_rowconfigure(0, weight=1)

        # LEFT: vehicle list + buttons
        self.frame_lista = ttk.Frame(self)
        self.frame_lista.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)
        self.frame_lista.grid_rowconfigure(0, weight=1)

        # Treeview
        self.colunas = [
            ("id", "ID"), ("marca", "Marca"), ("modelo", "Modelo"), ("matricula", "Matrícula"),
            ("ano", "Ano"), ("categoria", "Categoria"), ("transmissao", "Transmissão"),
            ("tipo", "Tipo"), ("lugares", "Lugares"),
            ("diaria", "Diária"), ("estado", "Estado")
        ]
        self.tree = ttk.Treeview(self.frame_lista, columns=[c[0] for c in self.colunas], show='headings', height=20)
        for chave, titulo in self.colunas:
            self.tree.heading(chave, text=titulo)
            self.tree.column(chave, width=80, anchor=tk.CENTER)
        self.tree.grid(row=0, column=0, sticky="nsew")
        self.tree.bind("<<TreeviewSelect>>", self.on_selecionar_veiculo)
        self.frame_lista.grid_rowconfigure(0, weight=1)
        self.frame_lista.grid_columnconfigure(0, weight=1)

        # Action buttons
        btn_frame = ttk.Frame(self.frame_lista)
        btn_frame.grid(row=1, column=0, sticky="ew", pady=5)
        for txt, cmd in [("Adicionar", self.abrir_formulario_adicionar),
                         ("Editar", self.abrir_formulario_editar),
                         ("Remover", self.remover_veiculo),
                         ("Manutenção", self.marcar_manutencao),
                         ("Exportar CSV", self.exportar_csv)]:
            ttk.Button(btn_frame, text=txt, command=cmd).pack(side=tk.LEFT, padx=3)

        # CENTER: form container
        self.center_frame = ttk.Frame(self)
        self.center_frame.grid(row=0, column=1, sticky="nsew", padx=5, pady=5)

        # RIGHT: large image preview
        self.image_frame = ttk.Frame(self)
        self.image_frame.grid(row=0, column=2, sticky="nsew", padx=5, pady=5)
        self.image_frame.grid_rowconfigure(0, weight=1)
        self.image_frame.grid_columnconfigure(0, weight=1)
        self.label_imagem = tk.Label(self.image_frame, text="Sem imagem", bd=1, relief="solid",
                                     anchor="center")
        self.label_imagem.grid(row=0, column=0, sticky="nsew")

        self.carregar_veiculos()

    def carregar_veiculos(self):
        """Load vehicles into Treeview."""
        for row in self.tree.get_children():
            self.tree.delete(row)
        lista = veiculos_servico.obter_veiculos_servico() or []
        for veiculo in lista:
            valores = [veiculo.get(chave, "") for chave, _ in self.colunas]
            self.tree.insert("", tk.END, values=valores)

    def on_selecionar_veiculo(self, event):
        """Handle vehicle selection from Treeview."""
        selecionado = self.tree.selection()
        if not selecionado:
            return
        valores = self.tree.item(selecionado[0])["values"]
        self.id_selecionado = int(valores[0]) if valores else None

        veiculos = veiculos_servico.obter_veiculos_servico() or []
        veiculo = next((v for v in veiculos if v.get("id") == self.id_selecionado), None)

        if veiculo and veiculo.get("imagem"):
            self.mostrar_imagem_lista(veiculo["imagem"])
        else:
            self.label_imagem.config(text="No image", image="")
            self.img_atual = None

    def _resolver_caminho_imagem(self, nome_arquivo: str) -> str:
        """Resolve correct path for an image."""
        if not nome_arquivo:
            return ""
        if os.path.isabs(nome_arquivo) and os.path.exists(nome_arquivo):
            return nome_arquivo
        caminho1 = os.path.join(PHOTO_DIR, nome_arquivo)
        if os.path.exists(caminho1):
            return caminho1
        caminho2 = os.path.join("photo_cars", nome_arquivo)
        if os.path.exists(caminho2):
            return caminho2
        return ""

    def mostrar_imagem_lista(self, nome_arquivo):
        """Show large image preview on the right, keeping aspect ratio."""
        caminho = self._resolver_caminho_imagem(nome_arquivo)
        if caminho and os.path.exists(caminho):
            # Get current label size
            largura_label = self.label_imagem.winfo_width() or 400
            altura_label = self.label_imagem.winfo_height() or 300

            img = Image.open(caminho)
            img.thumbnail((largura_label, altura_label), Image.Resampling.LANCZOS)
            self.img_atual = ImageTk.PhotoImage(img)
            self.label_imagem.config(image=self.img_atual, text="")
        else:
            self.label_imagem.config(text="Imagem não encontrada", image="")
            self.img_atual = None

    def abrir_formulario_adicionar(self):
        """Open form to add new vehicle."""
        if self.formulario:
            self.formulario.destroy()
            self.formulario = None
        # Always create the form inside center_frame and ensure it expands
        self.formulario = FormularioVeiculo(self.center_frame, "Adicionar Veículo", self.adicionar_veiculo)
        self.formulario.pack(fill=tk.BOTH, expand=True)

    def abrir_formulario_editar(self):
        """Open form to edit selected vehicle."""
        if not self.id_selecionado:
            messagebox.showwarning("Warning", "Select a vehicle to edit.")
            return
        veiculos = veiculos_servico.obter_veiculos_servico() or []
        veiculo = next((v for v in veiculos if v.get("id") == self.id_selecionado), None)
        if veiculo is None:
            messagebox.showerror("Error", "Vehicle not found.")
            return
        if self.formulario:
            self.formulario.destroy()
            self.formulario = None
        # Create form inside center_frame so it has enough horizontal space
        self.formulario = FormularioVeiculo(self.center_frame, "Editar Veículo", self.atualizar_veiculo, veiculo)
        self.formulario.pack(fill=tk.BOTH, expand=True)

    def adicionar_veiculo(self, dados):
        """Add vehicle via service layer."""
        sucesso = veiculos_servico.adicionar_veiculo_servico(**dados)
        if sucesso:
            messagebox.showinfo("Success", "Vehicle added successfully.")
            if self.formulario:
                self.formulario.destroy()
                self.formulario = None
            self.carregar_veiculos()
        else:
            messagebox.showerror("Error", "Failed to add vehicle.")

    def atualizar_veiculo(self, dados):
        """Update vehicle via service layer."""
        veiculo_id = dados.pop("veiculo_id")
        sucesso = veiculos_servico.atualizar_veiculo_servico(veiculo_id=int(veiculo_id), **dados)
        if sucesso:
            messagebox.showinfo("Success", "Vehicle updated successfully.")
            if self.formulario:
                self.formulario.destroy()
                self.formulario = None
            self.carregar_veiculos()
        else:
            messagebox.showerror("Error", "Failed to update vehicle.")

    def remover_veiculo(self):
        """Remove selected vehicle."""
        if not self.id_selecionado:
            messagebox.showwarning("Warning", "Select a vehicle to remove.")
            return
        if messagebox.askyesno("Confirmation", "Are you sure you want to remove the selected vehicle?"):
            sucesso = veiculos_servico.remover_veiculo_servico(self.id_selecionado)
            if sucesso:
                messagebox.showinfo("Success", "Vehicle removed successfully.")
                self.carregar_veiculos()
            else:
                messagebox.showerror("Error", "Failed to remove vehicle.")

    def marcar_manutencao(self):
        """Mark selected vehicle for maintenance."""
        if not self.id_selecionado:
            messagebox.showwarning("Warning", "Select a vehicle to mark for maintenance.")
            return
        sucesso = veiculos_servico.marcar_veiculo_manutencao_servico(self.id_selecionado)
        if sucesso:
            messagebox.showinfo("Success", "Vehicle marked for maintenance.")
            self.carregar_veiculos()
        else:
            messagebox.showerror("Error", "Failed to mark maintenance.")

    def exportar_csv(self):
        """Export vehicle list to CSV file."""
        caminho = filedialog.asksaveasfilename(defaultextension=".csv",
                                               filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
        if caminho:
            sucesso = veiculos_servico.exportar_veiculos_servico(caminho)
            if sucesso:
                messagebox.showinfo("Export", f"Exported to {caminho}")
            else:
                messagebox.showerror("Error", "Failed to export CSV.")


class FormularioVeiculo(ttk.Frame):
    """Form for adding or editing a vehicle, with vertical scrollbar."""

    def __init__(self, pai, titulo, callback_salvar, veiculo=None):
        """
        Build a scrollable form. The form is intended to be packed into a container
        that provides horizontal space (the center_frame in AplicacaoVeiculo).
        """
        super().__init__(pai)

        self.callback_salvar = callback_salvar
        self.veiculo = veiculo
        self.entries = {}
        self.img_atual = None

        # Create canvas + scrollbar + scrollable_frame
        canvas = tk.Canvas(self, borderwidth=0)
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        self.scrollable_frame = ttk.Frame(canvas)

        # When the inner frame changes size, update scrollregion
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas_window = canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Use grid in this widget so we can make canvas expand
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)

        canvas.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")

        # Keep the inner frame width matched to the canvas width so the form doesn't compress
        def _on_canvas_configure(event):
            canvas.itemconfig(canvas_window, width=event.width)
        canvas.bind("<Configure>", _on_canvas_configure)

        # Title
        ttk.Label(self.scrollable_frame, text=titulo, font=("Arial", 14, "bold")).grid(
            row=0, column=0, columnspan=2, pady=10
        )

        campos = [
            ("Marca", "marca"), ("Modelo", "modelo"), ("Matrícula", "matricula"),
            ("Ano", "ano"), ("Categoria", "categoria"), ("Transmissão", "transmissao"),
            ("Tipo Veículo", "tipo"), ("Lugares", "lugares"),
            ("Imagem", "imagem"), ("Diária", "diaria"),
            ("Última Revisão", "data_ultima_revisao"), ("Próxima Revisão", "data_proxima_revisao"),
            ("Última Inspeção", "data_ultima_inspecao"), ("Próxima Inspeção", "data_proxima_inspecao")
        ]

        # Add form fields (labels + entries) to the scrollable frame
        for i, (texto, chave) in enumerate(campos, start=1):
            ttk.Label(self.scrollable_frame, text=texto, width=20).grid(
                row=i, column=0, sticky="w", pady=2, padx=2
            )
            entry = ttk.Entry(self.scrollable_frame)
            entry.grid(row=i, column=1, sticky="ew", pady=2, padx=2)  # expand horizontally
            self.entries[chave] = entry

        # Make column 1 grow so the entries expand horizontally
        self.scrollable_frame.grid_columnconfigure(1, weight=1)

        # Small image preview inside the form (thumbnail)
        self.label_preview = tk.Label(self.scrollable_frame, text="Pré-visualização da imagem", bd=1, relief="solid",
                                      width=30, height=8, anchor="center")
        self.label_preview.grid(row=len(campos) + 1, column=0, columnspan=2, pady=10)

        # Save button below everything
        self.btn_salvar = ttk.Button(self.scrollable_frame, text="Salvar", command=self.salvar)
        self.btn_salvar.grid(row=len(campos) + 2, column=0, columnspan=2, pady=10, sticky="ew")

        # Pre-fill fields if editing
        if veiculo:
            for chave, entry in self.entries.items():
                valor = veiculo.get(chave, "")
                entry.delete(0, tk.END)
                entry.insert(0, valor or "")
            if veiculo.get("imagem"):
                self.mostrar_imagem(veiculo["imagem"])

        # Optional: allow mousewheel scrolling when cursor is over canvas
        def _on_mousewheel(event):
            # For Windows and Mac generalization
            delta = -1 * (event.delta // 120) if event.delta else (1 if event.num == 5 else -1)
            canvas.yview_scroll(delta, "units")
        # bind on enter/leave to avoid interfering with other widgets
        canvas.bind_all("<MouseWheel>", _on_mousewheel)   # Windows/mac
        canvas.bind_all("<Button-4>", _on_mousewheel)     # Linux scroll up
        canvas.bind_all("<Button-5>", _on_mousewheel)     # Linux scroll down

    def mostrar_imagem(self, nome_arquivo):
        """Show image thumbnail inside the form."""
        caminho = os.path.join(PHOTO_DIR, nome_arquivo)
        if os.path.exists(caminho):
            try:
                img = Image.open(caminho)
                img.thumbnail((260, 180), Image.Resampling.LANCZOS)
            except AttributeError:
                img = Image.open(caminho)
                img.thumbnail((260, 180), Image.ANTIALIAS)
            self.img_atual = ImageTk.PhotoImage(img)
            self.label_preview.config(image=self.img_atual, text="")
        else:
            self.label_preview.config(text="Image not found", image="")

    def salvar(self):
        """Validate and save vehicle data."""
        dados = {chave: ent.get().strip() for chave, ent in self.entries.items()}
        try:
            if dados.get("ano"):
                dados["ano"] = int(dados["ano"])
            if dados.get("lugares"):
                dados["lugares"] = int(dados["lugares"])
            if dados.get("diaria"):
                dados["diaria"] = float(dados["diaria"])
        except ValueError:
            messagebox.showerror("Error", "Year, Seats and Daily Rate must be numeric.")
            return

        if self.veiculo:
            dados["veiculo_id"] = self.veiculo.get("id")

        self.callback_salvar(dados)


if __name__ == "__main__":
    root = tk.Tk()
    app = AplicacaoVeiculo(root)
    root.mainloop()
