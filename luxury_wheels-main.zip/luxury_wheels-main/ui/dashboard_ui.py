import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

from controllers.cliente.cliente_servico import listar_clientes
from controllers.veiculos.veiculos_servico import obter_veiculos_servico
from controllers.reservas.reservas_servico import obter_reservas_servico
from controllers.pagamentos.pagamento_servico import obter_pagamentos
from controllers.dashboard.dashboard_servico import obter_reservas_agrupadas_por_mes


class AplicacaoDashboard(ttk.Frame):
    """
    Graphical interface for the Luxury Wheels Dashboard.

    Displays key fleet and reservation indicators:
        - Total clients
        - Available vehicles
        - Active reservations
        - Total revenue
    Also includes a bar chart showing reservations grouped by month.
    """

    def __init__(self, mestre: tk.Tk):
        """
        Initializes the dashboard interface.

        Args:
            mestre (tk.Tk): Main Tkinter window.
        """
        super().__init__(mestre, padding=10)
        mestre.title("Dashboard - Luxury Wheels")
        mestre.geometry("800x500")
        mestre.columnconfigure(0, weight=1)
        mestre.rowconfigure(1, weight=1)

        self._etiqueta_erro: ttk.Label | None = None

        self._criar_widgets()
        self._dispor_widgets()
        self._inicializar_grafico()
        self.atualizar()

    def _criar_widgets(self) -> None:
        """Creates dashboard widgets: indicators, refresh button, and chart."""
        self.quadro_indicadores = ttk.Frame(self)
        self.etq_clientes = ttk.Label(
            self.quadro_indicadores, text="Clients: —", anchor="center", font=("Segoe UI", 10, "bold")
        )
        self.etq_veiculos = ttk.Label(
            self.quadro_indicadores, text="Vehicles Avail.: —", anchor="center", font=("Segoe UI", 10, "bold")
        )
        self.etq_reservas = ttk.Label(
            self.quadro_indicadores, text="Active Reservations: —", anchor="center", font=("Segoe UI", 10, "bold")
        )
        self.etq_receita = ttk.Label(
            self.quadro_indicadores, text="Total Revenue: —", anchor="center", font=("Segoe UI", 10, "bold")
        )
        self.btn_atualizar = ttk.Button(self.quadro_indicadores, text="Refresh", command=self.atualizar)

        self.quadro_grafico = ttk.Frame(self)
        self.figura = plt.Figure(figsize=(6, 3), tight_layout=True)
        self.eixo = self.figura.add_subplot(111)
        self.canvas = FigureCanvasTkAgg(self.figura, master=self.quadro_grafico)

    def _dispor_widgets(self) -> None:
        """Arranges the widgets in the interface using the grid layout."""
        self.quadro_indicadores.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        for idx, widget in enumerate((
            self.etq_clientes,
            self.etq_veiculos,
            self.etq_reservas,
            self.etq_receita,
            self.btn_atualizar
        )):
            widget.grid(row=0, column=idx, padx=5, sticky="nsew")
            self.quadro_indicadores.columnconfigure(idx, weight=1)

        self.quadro_grafico.grid(row=1, column=0, sticky="nsew")
        self.quadro_grafico.rowconfigure(0, weight=1)
        self.quadro_grafico.columnconfigure(0, weight=1)
        self.canvas.get_tk_widget().grid(row=0, column=0, sticky="nsew")

        self.grid(sticky="nsew")

    def _inicializar_grafico(self) -> None:
        """Sets up the axes, title, and labels for the reservations per month chart."""
        self.eixo.set_title("Reservations per Month")
        self.eixo.set_xlabel("Month")
        self.eixo.set_ylabel("Total Reservations")
        self.eixo.tick_params(axis="x", rotation=45)

    def _atualizar_grafico(self) -> None:
        """Updates the bar chart with reservations grouped by month data."""
        dados = obter_reservas_agrupadas_por_mes()
        if dados:
            meses = [
                str(d.get("mes") or d.get("mes_num") or d.get("month") or d.get("mês") or "?")
                for d in dados
            ]
            totais = [d.get("total", 0) for d in dados]
        else:
            meses, totais = [], []

        self.eixo.clear()
        self._inicializar_grafico()
        self.eixo.bar(meses, totais, color="skyblue")
        self.canvas.draw()

    def atualizar(self) -> None:
        """
        Updates all dashboard indicators and the chart.

        Captures possible exceptions and displays an error message on the interface.
        """
        if self._etiqueta_erro:
            self._etiqueta_erro.destroy()
            self._etiqueta_erro = None

        try:
            # Total clients
            total_clientes = len(listar_clientes())

            # Total available vehicles
            veiculos = obter_veiculos_servico()
            total_veiculos = len([v for v in veiculos if v.get("estado") == "disponível"])

            # Total active reservations
            reservas = obter_reservas_servico()
            total_reservas = len([r for r in reservas if r.get("estado") in ("Confirmada", "Pendente")])

            # Total revenue
            pagamentos = obter_pagamentos()
            receita_total = sum(float(p.get("valor", 0.0)) for p in pagamentos) if pagamentos else 0.0

            # Update labels
            self.etq_clientes.config(text=f"Clients: {total_clientes}")
            self.etq_veiculos.config(text=f"Vehicles Avail.: {total_veiculos}")
            self.etq_reservas.config(text=f"Active Reservations: {total_reservas}")
            self.etq_receita.config(text=f"Total Revenue: € {receita_total:,.2f}")

            # Update chart
            self._atualizar_grafico()

        except Exception as e:
            import traceback
            traceback.print_exc()
            self._etiqueta_erro = ttk.Label(
                self, text=f"Error updating dashboard: {e}", foreground="red"
            )
            self._etiqueta_erro.grid(row=2, column=0, pady=10)


if __name__ == "__main__":
    raiz = tk.Tk()
    app = AplicacaoDashboard(raiz)
    raiz.mainloop()
