import tkinter as tk
from tkinter import ttk, messagebox
from typing import Optional
from utils.tooltip import DicaFerramenta
from controllers.formas_pagamento.formas_pag_servico import (
    adicionar_forma_pagamento,
    editar_forma_pagamento,
    excluir_forma_pagamento,
    exportar_formas_pagamento_para_csv,
    obter_formas_pagamento
)


class AplicacaoFormasPagamento(ttk.Frame):
    """
    Graphical interface for managing payment methods.

    Allows adding, updating, removing, listing, and exporting payment methods
    using a form interface, action buttons, and a table (Treeview).
    """
    TAMANHO_MIN_NOME = 3

    def __init__(self, mestre: Optional[tk.Tk] = None):
        """
        Initializes the payment methods application.

        Args:
            mestre (Optional[tk.Tk]): Main application window.
        """
        super().__init__(mestre, padding=10)
        if mestre is not None:
            mestre.title("Payment Methods Management")
            mestre.geometry("400x350")
            mestre.resizable(True, True)

        self.pack(fill=tk.BOTH, expand=True)
        self._construir_formulario()
        self._construir_botoes()
        self._construir_lista()
        self._carregar_lista()

    def _construir_formulario(self) -> None:
        """
        Creates the input form with ID and Name fields for the payment method.
        The ID field is readonly, and the Name field has a tooltip with minimum character instructions.
        """
        formulario = ttk.Labelframe(self, text="Payment Method Data", padding=10)
        formulario.pack(fill=tk.X, pady=5)

        etiquetas = [("ID", False), ("Name", True)]
        self.campos = {}

        for i, (texto_etiqueta, editavel) in enumerate(etiquetas):
            ttk.Label(formulario, text=f"{texto_etiqueta}:").grid(row=i, column=0, sticky=tk.E, padx=5, pady=2)
            entrada = ttk.Entry(formulario, width=40)
            entrada.grid(row=i, column=1, sticky=tk.W, padx=5, pady=2)

            if not editavel:
                entrada.state(["readonly"])
            else:
                DicaFerramenta(entrada, f"{texto_etiqueta}: minimum {self.TAMANHO_MIN_NOME} characters")

            self.campos[texto_etiqueta.lower()] = entrada

    def _construir_botoes(self) -> None:
        """
        Creates the action buttons for the application: Add, Update, Remove, Clear, and Export CSV.
        """
        quadro_botoes = ttk.Frame(self)
        quadro_botoes.pack(fill=tk.X, pady=5)

        ttk.Button(quadro_botoes, text="Add", command=self.adicionar).pack(side=tk.LEFT, padx=5)
        ttk.Button(quadro_botoes, text="Update", command=self.atualizar).pack(side=tk.LEFT, padx=5)
        ttk.Button(quadro_botoes, text="Remove", command=self.remover).pack(side=tk.LEFT, padx=5)
        ttk.Button(quadro_botoes, text="Clear", command=self.limpar).pack(side=tk.LEFT, padx=5)
        ttk.Button(quadro_botoes, text="Export CSV", command=self.exportar).pack(side=tk.RIGHT, padx=5)

    def _construir_lista(self) -> None:
        """
        Creates the Treeview to display all registered payment methods,
        with a scrollbar and selection event.
        """
        quadro_lista = ttk.Frame(self)
        quadro_lista.pack(fill=tk.BOTH, expand=True, pady=5)

        colunas = ("id", "nome")
        self.arvore = ttk.Treeview(quadro_lista, columns=colunas, show="headings", selectmode="browse")
        self.arvore.heading("id", text="ID")
        self.arvore.column("id", width=50, anchor=tk.CENTER)
        self.arvore.heading("nome", text="Name")
        self.arvore.column("nome", width=300, anchor=tk.CENTER)

        barra_scroll = ttk.Scrollbar(quadro_lista, orient=tk.VERTICAL, command=self.arvore.yview)
        self.arvore.configure(yscroll=barra_scroll.set)
        self.arvore.grid(row=0, column=0, sticky="nsew")
        barra_scroll.grid(row=0, column=1, sticky="ns")

        quadro_lista.rowconfigure(0, weight=1)
        quadro_lista.columnconfigure(0, weight=1)
        self.arvore.bind("<<TreeviewSelect>>", self._ao_selecionar)

    # ------------------------ Field Manipulation ------------------------
    def _obter_valor(self, campo: str) -> str:
        """
        Returns the value of the given field.

        Args:
            campo (str): Field name ('id' or 'nome').

        Returns:
            str: Current value of the field.
        """
        return self.campos[campo].get().strip()

    def _definir_valor(self, campo: str, valor: str) -> None:
        """
        Sets the value of a field. The 'id' field remains readonly.

        Args:
            campo (str): Field name ('id' or 'nome').
            valor (str): Value to set in the field.
        """
        entrada = self.campos[campo]
        if campo == "id":
            entrada.state(["!readonly"])
            entrada.delete(0, tk.END)
            entrada.insert(0, valor or "")
            entrada.state(["readonly"])
        else:
            entrada.delete(0, tk.END)
            entrada.insert(0, valor or "")

    # ------------------------ Validation ------------------------
    def _validar(self) -> bool:
        """
        Validates the 'nome' field and checks for duplicate names.

        Returns:
            bool: True if data is valid, False otherwise.
        """
        nome = self._obter_valor("nome")
        if len(nome) < self.TAMANHO_MIN_NOME:
            messagebox.showerror("Error", f"Name must have at least {self.TAMANHO_MIN_NOME} characters.")
            return False

        formas_existentes = obter_formas_pagamento()
        id_atual = self._obter_valor("id")
        nome_atual = nome.lower()

        for fp in formas_existentes:
            id_fp, nome_fp = (fp["id"], fp["metodo"]) if isinstance(fp, dict) else fp
            if nome_fp.lower() == nome_atual and (not id_atual or int(id_atual) != id_fp):
                messagebox.showerror("Error", "Name is already registered.")
                return False

        return True

    # ------------------------ Actions ------------------------
    def adicionar(self) -> None:
        """
        Adds a new payment method after validation.
        Displays success or error messages.
        """
        if not self._validar():
            return
        nome = self._obter_valor("nome")
        if adicionar_forma_pagamento(nome):
            messagebox.showinfo("Success", "Payment method added.")
            self.limpar()
            self._carregar_lista()
        else:
            messagebox.showerror("Error", "Failed to add. Check the provided name.")

    def atualizar(self) -> None:
        """
        Updates the selected payment method after validation.
        Displays success or error messages.
        """
        if not self._validar():
            return
        id_str = self._obter_valor("id")
        if not id_str:
            messagebox.showerror("Error", "Select a method to update.")
            return
        nome = self._obter_valor("nome")
        if editar_forma_pagamento(int(id_str), nome):
            messagebox.showinfo("Success", "Payment method updated.")
            self.limpar()
            self._carregar_lista()
        else:
            messagebox.showerror("Error", "Failed to update. Check the provided name.")

    def remover(self) -> None:
        """
        Removes the selected payment method after user confirmation.
        """
        id_str = self._obter_valor("id")
        if not id_str:
            messagebox.showerror("Error", "Select a method to remove.")
            return
        if messagebox.askyesno("Confirm", "Remove this payment method?"):
            if excluir_forma_pagamento(int(id_str)):
                messagebox.showinfo("Success", "Payment method removed.")
                self.limpar()
                self._carregar_lista()
            else:
                messagebox.showerror("Error", "Failed to remove payment method.")

    # ------------------------ Selection and Listing ------------------------
    def _ao_selecionar(self, _evento: tk.Event) -> None:
        """
        Fills the form fields with data selected from the Treeview.

        Args:
            _evento (tk.Event): Selection event (not directly used).
        """
        selecionados = self.arvore.selection()
        if selecionados:
            valores = self.arvore.item(selecionados[0], "values")
            self._definir_valor("id", valores[0])
            self._definir_valor("nome", valores[1])

    def _carregar_lista(self) -> None:
        """
        Updates the Treeview with all registered payment methods.
        """
        for item in self.arvore.get_children():
            self.arvore.delete(item)
        for linha in obter_formas_pagamento():
            if isinstance(linha, dict):
                self.arvore.insert("", tk.END, values=(linha["id"], linha["metodo"]))
            else:
                self.arvore.insert("", tk.END, values=linha)

    # ------------------------ Clear and Export ------------------------
    def limpar(self) -> None:
        """
        Clears all form fields.
        """
        for campo in self.campos:
            self._definir_valor(campo, "")

    def exportar(self) -> None:
        """
        Exports payment methods to CSV.
        Displays success or error messages.
        """
        if exportar_formas_pagamento_para_csv():
            messagebox.showinfo("Success", "Exported to CSV successfully.")
        else:
            messagebox.showerror("Error", "Failed to export CSV.")


if __name__ == "__main__":
    raiz = tk.Tk()
    app = AplicacaoFormasPagamento(raiz)
    raiz.mainloop()
