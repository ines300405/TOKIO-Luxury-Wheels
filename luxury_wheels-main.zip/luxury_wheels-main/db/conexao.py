import sqlite3
import os

def conectar_base_dados() -> sqlite3.Connection:
    """
    Establishes a connection to the SQLite database.

    The database is located in the same directory as this script,
    and the file must be named 'luxury_wheels.db'.

    Returns:
    sqlite3.Connection: Database connection object.

    Exceptions:
    sqlite3.Error: Raises an exception if there is an error while attempting to connect.
.
    """
    diretorio_base = os.path.dirname(os.path.abspath(__file__))
    caminho_base_dados = os.path.join(diretorio_base, "luxury_wheels.db")
    return sqlite3.connect(caminho_base_dados)
