from conexao import conectar_base_dados

def criar_tabelas() -> None:
    """
    Creates all necessary tables for the Luxury Wheels application.

Tables created:
    - users: manages system users (admin or manager).
    - clients: company client records.
    - vehicles: vehicle inventory with complete information.
    - payment_methods: available payment methods.
    - reservations: reservations made by clients.
    - payments: payments made for reservations.
    - maintenances: records of maintenance performed on vehicles.

Notes:
    - Uses FOREIGN KEYS to ensure referential integrity.
    - Tables are only created if they do not already exist.
    """
    conn = conectar_base_dados()
    cursor = conn.cursor()

    cursor.executescript("""
    CREATE TABLE IF NOT EXISTS utilizadores (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        senha TEXT NOT NULL,
        perfil TEXT DEFAULT 'gestor'  -- Pode ser 'admin' ou 'gestor'
    );

    CREATE TABLE IF NOT EXISTS clientes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        email TEXT UNIQUE,
        telefone TEXT,
        nif TEXT,
        data_registo TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS veiculos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        marca TEXT,
        modelo TEXT,
        matricula TEXT UNIQUE,
        ano INTEGER,
        km_atual INTEGER,
        data_ultima_revisao TEXT,
        data_proxima_revisao TEXT,
        categoria TEXT,
        transmissao TEXT,
        tipo TEXT,
        lugares INTEGER,
        imagem TEXT,
        diaria REAL,
        data_ultima_inspecao TEXT,
        data_proxima_inspecao TEXT,
        estado TEXT DEFAULT 'disponível'  -- Ex: disponível, alugado, em manutenção
    );

    CREATE TABLE IF NOT EXISTS formaspagamento (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        metodo TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS reservas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_cliente INTEGER,
        id_veiculo INTEGER,
        data_inicio TEXT,
        data_fim TEXT,
        estado TEXT DEFAULT 'Pendente',  -- Confirmada, Concluída, Pendente, Cancelada
        FOREIGN KEY (id_cliente) REFERENCES clientes(id),
        FOREIGN KEY (id_veiculo) REFERENCES veiculos(id)
    );

    CREATE TABLE IF NOT EXISTS pagamentos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_reserva INTEGER,
        id_forma_pagamento INTEGER,
        valor REAL,
        data_pagamento TEXT DEFAULT (datetime('now')),
        FOREIGN KEY (id_reserva) REFERENCES reservas(id),
        FOREIGN KEY (id_forma_pagamento) REFERENCES formaspagamento(id)
    );

    CREATE TABLE IF NOT EXISTS manutencoes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_veiculo INTEGER,
        descricao TEXT,
        data_manutencao TEXT,
        custo REAL,
        FOREIGN KEY (id_veiculo) REFERENCES veiculos(id)
    );
    """)

    conn.commit()
    conn.close()
    print("Tabelas criadas com sucesso.")


if __name__ == "__main__":
    criar_tabelas()
