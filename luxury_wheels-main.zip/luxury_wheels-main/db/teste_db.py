from db.conexao import conectar_base_dados

"""
Test script for the SQLite database connection.

Checks:
    - Whether the connection can be established.
    - The path of the database in use.
"""

# Establishes connection to the database
conn = conectar_base_dados()

# Displays the connection object (useful for debugging)
print(conn)

# Shows information about attached databases, including the path
print("Usando banco em:", conn.execute("PRAGMA database_list").fetchall())

# Closes the connection to free resources
conn.close()
