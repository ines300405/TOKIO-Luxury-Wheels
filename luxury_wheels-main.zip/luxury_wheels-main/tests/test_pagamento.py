import unittest
from controllers.pagamentos import pagamento_servico, pagamento_repositorio
from datetime import date

class TestPayment(unittest.TestCase):
    """
    Unit tests for payment operations.
    Includes creation, editing, listing, and removal of records.
    """

    def setUp(self):
        """
        Runs before each test:
        - Creates a temporary payment for testing.
        """
        self.payment_data = {
            "data_pagamento": str(date.today()),   # YYYY-MM-DD format
            "valor": 50.0,
            "id_forma_pagamento": 1,  # must exist in the test DB
            "id_reserva": 1           # must exist in the test DB
        }
        success, msg = pagamento_servico.adicionar_pagamento(self.payment_data)
        self.assertTrue(success, f"Failed to create payment in setUp: {msg}")

        # Get the generated payment ID
        payments = pagamento_servico.obter_pagamentos()
        self.assertGreater(len(payments), 0, "No payment found after insertion.")
        self.payment_id = payments[0]["id"]

    def tearDown(self):
        """
        Runs after each test:
        - Removes the temporary payment created in setUp.
        """
        if self.payment_id:
            pagamento_repositorio.remover_pagamento_bd(self.payment_id)

    def test_edit_payment(self):
        """
        Tests editing an existing payment.
        - Updates the payment amount.
        - Checks if the update was successful.
        - Confirms the value in the database is correct.
        """
        new_data = {
            "id_pagamento": self.payment_id,
            "data_pagamento": str(date.today()),
            "valor": 100.0,
            "id_forma_pagamento": 1,
            "id_reserva": 1
        }
        success, msg = pagamento_servico.editar_pagamento(new_data)
        self.assertTrue(success, f"Editing payment failed: {msg}")

        payment = pagamento_repositorio.buscar_pagamento_por_id(self.payment_id)
        self.assertIsNotNone(payment)
        self.assertEqual(payment["valor"], 100.0)

    def test_edit_nonexistent_payment(self):
        """
        Tests editing a non-existent payment.
        - Should return False indicating failure.
        """
        new_data = {
            "id_pagamento": 99999,
            "data_pagamento": str(date.today()),
            "valor": 200.0,
            "id_forma_pagamento": 1,
            "id_reserva": 1
        }
        success, msg = pagamento_servico.editar_pagamento(new_data)
        self.assertFalse(success, "Should fail when editing a non-existent payment.")

    def test_list_payments(self):
        """
        Tests listing of payments.
        - Checks that the return value is a list.
        - Ensures at least one payment exists.
        """
        payments = pagamento_servico.obter_pagamentos()
        self.assertIsInstance(payments, list)
        self.assertGreater(len(payments), 0)

    def test_remove_payment(self):
        """
        Tests removal of a payment.
        - Creates a temporary payment.
        - Removes it and checks that removal was successful.
        """
        data = {
            "data_pagamento": str(date.today()),
            "valor": 75.0,
            "id_forma_pagamento": 1,
            "id_reserva": 1
        }
        success, msg = pagamento_servico.adicionar_pagamento(data)
        self.assertTrue(success, f"Failed to create payment for removal: {msg}")

        # Get the latest payment ID
        payments = pagamento_servico.obter_pagamentos()
        new_id = payments[0]["id"]

        removed = pagamento_servico.excluir_pagamento(new_id)
        self.assertTrue(removed, "Removing payment should return True")
