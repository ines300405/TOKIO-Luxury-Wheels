import unittest
from controllers.formas_pagamento import formas_pag_servico
from controllers.formas_pagamento import formas_pag_repositorio

class TestPaymentMethodsDB(unittest.TestCase):
    """
    Unit tests for payment methods operations in the database.
    Includes creation, listing, editing, deletion, and CSV export.
    """

    def setUp(self):
        """
        Runs before each test:
        - Initializes the payment methods table if necessary.
        - Creates a temporary payment method for testing.
        """
        formas_pag_servico.inicializar_formas_pagamento()
        self.method = "Test Card"
        success = formas_pag_servico.adicionar_forma_pagamento(self.method)
        self.assertTrue(success, "Failed to create payment method in setUp")
        # Get the ID of the created method
        methods = formas_pag_servico.obter_formas_pagamento()
        self.method_id = methods[-1][0]  # take the last inserted

    def tearDown(self):
        """
        Runs after each test:
        - Removes the temporary payment method created in setUp.
        """
        formas_pag_repositorio.remover_forma_pagamento_bd(self.method_id)

    def test_list_payment_methods(self):
        """
        Tests listing of payment methods.
        - Checks that the result is a list.
        - Confirms at least one method exists.
        - Ensures the method created in setUp is in the list.
        """
        methods = formas_pag_servico.obter_formas_pagamento()
        self.assertIsInstance(methods, list)
        self.assertGreater(len(methods), 0)
        self.assertIn((self.method_id, self.method), methods)

    def test_edit_payment_method(self):
        """
        Tests updating an existing payment method.
        - Changes the method name.
        - Checks that the update was successful.
        - Confirms the new name is correct in the database.
        """
        new_name = "Updated Card"
        result = formas_pag_servico.editar_forma_pagamento(self.method_id, new_name)
        self.assertTrue(result)
        updated_method = formas_pag_repositorio.buscar_forma_pagamento_por_id(self.method_id)
        self.assertEqual(updated_method["metodo"], new_name)

    def test_delete_payment_method(self):
        """
        Tests deletion of a payment method.
        - Creates a new method specifically for deletion.
        - Executes deletion and confirms success.
        - Ensures the method no longer exists in the database.
        """
        formas_pag_servico.adicionar_forma_pagamento("Test MB WAY")
        methods = formas_pag_servico.obter_formas_pagamento()
        new_id = methods[-1][0] if methods[-1][0] != self.method_id else methods[-2][0]

        result = formas_pag_servico.excluir_forma_pagamento(new_id)
        self.assertTrue(result)
        deleted_method = formas_pag_repositorio.buscar_forma_pagamento_por_id(new_id)
        self.assertIsNone(deleted_method)

    def test_export_payment_methods_to_csv(self):
        """
        Tests exporting payment methods to a CSV file.
        - Checks that the function returns True indicating success.
        """
        result = formas_pag_servico.exportar_formas_pagamento_para_csv("test_payment_methods.csv")
        self.assertTrue(result, "CSV export should return True")
