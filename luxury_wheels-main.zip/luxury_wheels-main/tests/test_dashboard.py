import unittest
from controllers.dashboard import dashboard_servico

class TestDashboard(unittest.TestCase):
    """
    Unit tests for dashboard services.
    Checks metrics such as total clients, available vehicles,
    active reservations, and total payment revenue.
    """

    def test_get_total_clients(self):
        """
        Tests the function that returns the total number of clients.
        - Ensures the value is not None.
        - Confirms it is an integer.
        - Ensures it is non-negative.
        """
        total = dashboard_servico.obter_total_clientes()
        self.assertIsNotNone(total, "Total clients should not be None")
        self.assertIsInstance(total, int, "Result should be an integer")
        self.assertGreaterEqual(total, 0, "Total clients cannot be negative")

    def test_get_total_available_vehicles(self):
        """
        Tests the function that returns the total available vehicles.
        - Ensures the value is not None.
        - Confirms it is an integer.
        - Ensures it is non-negative.
        """
        total = dashboard_servico.obter_total_veiculos_disponiveis()
        self.assertIsNotNone(total, "Total vehicles should not be None")
        self.assertIsInstance(total, int, "Result should be an integer")
        self.assertGreaterEqual(total, 0, "Total available vehicles cannot be negative")

    def test_get_total_active_reservations(self):
        """
        Tests the function that returns the total active reservations.
        - Ensures the value is not None.
        - Confirms it is an integer.
        - Ensures it is non-negative.
        """
        total = dashboard_servico.obter_total_reservas_ativas()
        self.assertIsNotNone(total, "Total reservations should not be None")
        self.assertIsInstance(total, int, "Result should be an integer")
        self.assertGreaterEqual(total, 0, "Total active reservations cannot be negative")

    def test_calculate_total_payment_revenue(self):
        """
        Tests the function that calculates total payment revenue.
        - Ensures the value is not None.
        - Confirms it is numeric (int or float).
        - Ensures it is non-negative.
        """
        revenue = dashboard_servico.calcular_receita_total_pagamentos()
        self.assertIsNotNone(revenue, "Total revenue should not be None")
        self.assertIsInstance(revenue, (int, float), "Result should be numeric")
        self.assertGreaterEqual(revenue, 0.0, "Total revenue cannot be negative")

    def test_get_reservations_grouped_by_month(self):
        """
        Tests the function that groups reservations by month.
        - Ensures the result is a list.
        - Checks each item contains 'mes' and 'total' keys.
        - Validates types and non-negative totals.
        """
        reservations = dashboard_servico.obter_reservas_agrupadas_por_mes()
        self.assertIsInstance(reservations, list, "Result should be a list")

        if reservations:  # Only validate content if there are results
            for item in reservations:
                self.assertIn("mes", item, "Each item should contain 'mes' key")
                self.assertIn("total", item, "Each item should contain 'total' key")
                self.assertIsInstance(item["mes"], str, "'mes' field should be a string (YYYY-MM)")
                self.assertIsInstance(item["total"], int, "'total' field should be an integer")
                self.assertGreaterEqual(item["total"], 0, "Monthly reservation total cannot be negative")
