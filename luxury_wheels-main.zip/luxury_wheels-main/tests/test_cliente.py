import unittest
import random
import string
from controllers.cliente import cliente_repositorio

class TestCliente(unittest.TestCase):
    """
    Unit tests for client CRUD operations.
    Uses dynamically generated test clients to avoid conflicts.
    """

    def setUp(self):
        """
        Runs before each test:
        - Generates a test client with a unique email.
        - Removes any existing client with the same email.
        - Adds the test client to the database for testing.
        """
        self.name = "Test Client"
        suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
        self.email = f"test_{suffix}@example.com"
        self.phone = "912345678"
        self.nif = "123456789"

        # Remove existing client with same email
        existing = cliente_repositorio.buscar_cliente_por_email(self.email)
        if existing:
            cliente_repositorio.remover_cliente(existing["id"])

        # Add test client
        success = cliente_repositorio.adicionar_cliente(
            self.name, self.email, self.phone, self.nif
        )
        self.assertTrue(success, "Failed to create client in setUp")

        # Store created client ID
        client = cliente_repositorio.buscar_cliente_por_email(self.email)
        self.assertIsNotNone(client, "Client not found after creation")
        self.client_id = client["id"]

    def tearDown(self):
        """
        Runs after each test:
        - Removes the test client from the database.
        """
        if hasattr(self, "client_id") and self.client_id:
            cliente_repositorio.remover_cliente(self.client_id)

    def test_update_client(self):
        """
        Tests updating an existing client:
        - Changes the client's name.
        - Checks if the change is persisted in the database.
        """
        new_name = "New Name"
        success = cliente_repositorio.atualizar_cliente(
            self.client_id, new_name, self.email, self.phone, self.nif
        )
        self.assertTrue(success, "Failed to update client")

        # Verify updated client by ID
        from controllers.cliente.cliente_repositorio import listar_clientes
        clients = listar_clientes()
        client = next((c for c in clients if c["id"] == self.client_id), None)

        self.assertIsNotNone(client, "Client not found after update")
        self.assertEqual(client["nome"], new_name)

    def test_list_clients(self):
        """
        Tests listing clients:
        - Checks if it returns a list.
        - Confirms that the list is not empty.
        """
        clients = cliente_repositorio.listar_clientes()
        self.assertIsInstance(clients, list)
        self.assertGreater(len(clients), 0)

    def test_update_nonexistent_client(self):
        """
        Tests updating a nonexistent client:
        - Should return False when trying to update an invalid ID.
        """
        result = cliente_repositorio.atualizar_cliente(
            99999, "Invalid", "inv@example.com", "999999999", "000000000"
        )
        self.assertFalse(result, "Should fail when updating nonexistent client")
