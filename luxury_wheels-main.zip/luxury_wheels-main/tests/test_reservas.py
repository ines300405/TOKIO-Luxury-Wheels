import unittest
from controllers.reservas import reservas_servico, reservas_repositorio

class TestReservasBD(unittest.TestCase):
    """
    Unit tests for reservation operations.
    Includes creation, editing, listing, and removal of reservations.
    """

    def setUp(self):
        """
        Runs before each test:
        - Creates a temporary reservation for testing.
        """
        self.reserva_dados = {
            "data_inicio": "2025-01-01",
            "data_fim": "2025-01-05",
            "cliente_id": 1,  # assumes a client with ID=1 exists
            "veiculo_id": 1,  # assumes a vehicle with ID=1 exists
            "status": "Confirmada",
            "valor_total": 300.0
        }
        sucesso = reservas_servico.adicionar_reserva_servico(**self.reserva_dados)
        self.assertTrue(sucesso, "Failed to create reservation in setUp")

        # Fetch the ID of the newly created reservation
        reservas = reservas_servico.obter_reservas_servico()
        self.reserva_id = reservas[0]["id"]

    def tearDown(self):
        """
        Runs after each test:
        - Removes the temporary reservation created in setUp.
        """
        reservas_repositorio.remover_reserva_bd(self.reserva_id)

    def test_listar_reservas(self):
        """
        Tests listing reservations.
        - Checks that the return value is a list.
        - Ensures at least one reservation exists.
        - Confirms that the reservation created in setUp is present.
        """
        reservas = reservas_servico.obter_reservas_servico()
        self.assertIsInstance(reservas, list)
        self.assertGreater(len(reservas), 0)
        self.assertEqual(reservas[0]["id"], self.reserva_id)

    def test_atualizar_reserva(self):
        """
        Tests updating an existing reservation.
        - Modifies start/end dates, status, and total value.
        - Confirms that the reservation was updated correctly in the DB.
        """
        resultado = reservas_servico.atualizar_reserva_servico(
            self.reserva_id,
            "2025-01-02",
            "2025-01-06",
            self.reserva_dados["cliente_id"],
            self.reserva_dados["veiculo_id"],
            "Cancelada",
            350.0
        )
        self.assertTrue(resultado)
        reserva_atualizada = reservas_repositorio.buscar_reserva_por_id(self.reserva_id)
        self.assertEqual(reserva_atualizada["estado"], "Cancelada")
        self.assertEqual(reserva_atualizada["valor_total"], 350.0)

    def test_excluir_reserva(self):
        """
        Tests deletion of a reservation.
        - Creates a new temporary reservation for deletion test.
        - Removes the reservation and confirms it no longer exists in the DB.
        """
        reservas_servico.adicionar_reserva_servico(
            "2025-02-01", "2025-02-05", 1, 1, "Confirmada", 400.0
        )
        reservas = reservas_servico.obter_reservas_servico()
        nova_id = reservas[0]["id"] if reservas[0]["id"] != self.reserva_id else reservas[1]["id"]

        resultado = reservas_servico.excluir_reserva_servico(nova_id)
        self.assertTrue(resultado)
        reserva_excluida = reservas_repositorio.buscar_reserva_por_id(nova_id)
        self.assertIsNone(reserva_excluida)
