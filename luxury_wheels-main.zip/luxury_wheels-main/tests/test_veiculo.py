import unittest
from controllers.veiculos import veiculos_servico

class TestVeiculo(unittest.TestCase):
    """
    Unit tests for vehicle operations.
    Includes creation, listing, editing, and removal of vehicles.
    """

    def setUp(self):
        """
        Runs before each test:
        - Defines a base vehicle for testing.
        - Removes any existing vehicles with the same license plate to avoid conflicts.
        - Inserts the test vehicle into the database.
        """
        self.dados_base = {
            "marca": "Toyota",
            "modelo": "Corolla",
            "ano": 2020,
            "matricula": "AA-11-BB",
            "categoria": "Sedan",
            "transmissao": "Manual",
            "tipo": "Carro",
            "lugares": 5,
            "imagem": "corolla.png",
            "diaria": 45.0,
            "data_ultima_revisao": "2023-01-01",
            "data_proxima_revisao": "2024-01-01",
            "data_ultima_inspecao": "2023-01-15",
            "data_proxima_inspecao": "2024-01-15",
            "km_atual": 0,
            "estado": "disponível"
        }

        # Remove vehicle with the same license plate
        veiculos = veiculos_servico.obter_veiculos_servico()
        for v in veiculos:
            if v["matricula"] == self.dados_base["matricula"]:
                veiculos_servico.remover_veiculo_servico(v["id"])

        # Insert base vehicle
        self.veiculo_id = veiculos_servico.adicionar_veiculo_servico(**self.dados_base)
        self.assertIsNotNone(self.veiculo_id, "Failed to insert test vehicle in setUp")

    def tearDown(self):
        """
        Runs after each test:
        - Removes the test vehicle created in setUp.
        """
        if self.veiculo_id:
            veiculos_servico.remover_veiculo_servico(self.veiculo_id)

    def test_listar_veiculos(self):
        """
        Tests listing vehicles.
        - Checks that the return value is a list.
        - Ensures at least one vehicle exists.
        """
        veiculos = veiculos_servico.obter_veiculos_servico()
        self.assertIsInstance(veiculos, list)
        self.assertGreater(len(veiculos), 0)

    def test_adicionar_veiculo(self):
        """
        Tests adding a new vehicle.
        - Creates a vehicle with a unique license plate.
        - Checks that insertion was successful.
        - Removes the created vehicle after the test.
        """
        novo_dados = self.dados_base.copy()
        novo_dados["marca"] = "Honda"
        novo_dados["modelo"] = "Civic"
        novo_dados["matricula"] = "CC-22-DD"

        veiculos = veiculos_servico.obter_veiculos_servico()
        for v in veiculos:
            if v["matricula"] == novo_dados["matricula"]:
                veiculos_servico.remover_veiculo_servico(v["id"])

        novo_id = veiculos_servico.adicionar_veiculo_servico(**novo_dados)
        self.assertIsNotNone(novo_id)
        veiculos_servico.remover_veiculo_servico(novo_id)

    def test_editar_veiculo(self):
        """
        Tests editing an existing vehicle.
        - Updates daily rate and mileage.
        - Confirms that the update was applied correctly.
        """
        dados_atualizados = self.dados_base.copy()
        dados_atualizados["diaria"] = 60.0
        dados_atualizados["km_atual"] = 15000

        atualizado = veiculos_servico.atualizar_veiculo_servico(self.veiculo_id, **dados_atualizados)
        self.assertTrue(atualizado, "Update failed: vehicle not found or invalid data")

        veiculos = veiculos_servico.obter_veiculos_servico()
        veiculo_atualizado = next((v for v in veiculos if v["id"] == self.veiculo_id), None)

        self.assertIsNotNone(veiculo_atualizado)
        self.assertAlmostEqual(float(veiculo_atualizado["diaria"]), 60.0)
        self.assertEqual(int(veiculo_atualizado["km_atual"]), 15000)

    def test_remover_veiculo(self):
        """
        Tests removing a vehicle.
        - Creates a temporary vehicle.
        - Removes it and checks that deletion was successful.
        """
        novo_dados = self.dados_base.copy()
        novo_dados["matricula"] = "EE-33-FF"

        veiculos = veiculos_servico.obter_veiculos_servico()
        for v in veiculos:
            if v["matricula"] == novo_dados["matricula"]:
                veiculos_servico.remover_veiculo_servico(v["id"])

        novo_id = veiculos_servico.adicionar_veiculo_servico(**novo_dados)
        removido = veiculos_servico.remover_veiculo_servico(novo_id)
        self.assertTrue(removido)

    def test_editar_veiculo_inexistente(self):
        """
        Tests updating a non-existent vehicle.
        - Should return False when trying to edit a vehicle with an invalid ID.
        """
        dados_invalidos = self.dados_base.copy()
        dados_invalidos["marca"] = "Invalido"
        resultado = veiculos_servico.atualizar_veiculo_servico(99999, **dados_invalidos)
        self.assertFalse(resultado)
